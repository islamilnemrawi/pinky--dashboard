package com.pinky.dashboard.data.remote

import com.pinky.dashboard.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/** Lightweight Gemini REST client. The API key is injected by the Gradle secrets plugin;
 * it is never hard-coded in the source tree. */
object PinkyGeminiClient {
    private const val MODEL = "gemini-2.5-flash"
    private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"
    private val client = OkHttpClient()

    suspend fun ask(question: String, storeContext: String): Result<String> = withContext(Dispatchers.IO) {
        val key = runCatching { BuildConfig.GEMINI_API_KEY }.getOrDefault("").trim()
        if (key.isBlank() || key.contains("placeholder", ignoreCase = true)) {
            return@withContext Result.failure(IllegalStateException("GEMINI_API_KEY is not configured"))
        }

        val system = """أنت مساعد Pinky الذكي داخل لوحة تحكم متجر إلكتروني.
أجب بالعربية الواضحة افتراضيًا، ويمكنك فهم الإنجليزية والعربية.
أجب عن الأسئلة العامة أيضًا، وليس فقط أسئلة المتجر.
عند السؤال عن المتجر استخدم سياق البيانات المرفق فقط ولا تخترع أرقامًا أو طلبات أو عملاء.
لا تكشف كلمات مرور أو مفاتيح API أو رموز جلسات أو بيانات اعتماد.
لا تعرض بيانات شخصية حساسة للعميل إلا إذا كانت ضرورية ومسموحًا بها من سياق السؤال.
إذا لم تتوفر معلومة من سياق المتجر، قل بوضوح إنها غير متاحة بدل التخمين.
كن عمليًا ومختصرًا عند الأسئلة الإدارية، واشرح عند الحاجة.

سياق متجر Pinky الحالي:
$storeContext"""

        val contents = JSONArray()
            .put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", system + "\n\nسؤال المستخدم:\n" + question))))

        val body = JSONObject().put("contents", contents).toString()
            .toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url("$ENDPOINT?key=$key")
            .post(body)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("Gemini HTTP ${response.code}: $raw"))
                }
                val root = JSONObject(raw)
                val candidates = root.optJSONArray("candidates") ?: return@withContext Result.failure(Exception("Gemini returned no candidates"))
                val text = candidates.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text")
                    .orEmpty()
                if (text.isBlank()) Result.failure(Exception("Gemini returned an empty response"))
                else Result.success(text.trim())
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
