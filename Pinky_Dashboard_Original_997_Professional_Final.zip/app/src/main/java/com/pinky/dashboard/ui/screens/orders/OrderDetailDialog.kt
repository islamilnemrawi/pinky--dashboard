package com.pinky.dashboard.ui.screens.orders

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.pinky.dashboard.core.util.Formatters
import com.pinky.dashboard.domain.model.Order
import com.pinky.dashboard.domain.model.OrderStatus
import com.pinky.dashboard.domain.model.PaymentMethod
import com.pinky.dashboard.domain.model.PaymentStatus
import com.pinky.dashboard.ui.components.OrderStatusBadge
import com.pinky.dashboard.ui.theme.PinkPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderDetailDialog(
    order: Order,
    onDismiss: () -> Unit,
    onStatusChange: (OrderStatus) -> Unit
) {
    val context = LocalContext.current
    var selectedStatus by remember { mutableStateOf(order.status) }
    var noteText by remember { mutableStateOf(order.notes) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.95f)
                .testTag("order_detail_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "طلب #${order.orderNumber}",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                color = PinkPrimary
                            )
                            if (order.prime) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFFFFD700).copy(alpha = 0.15f),
                                    border = BorderStroke(1.dp, Color(0xFFFFD700))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Star,
                                            contentDescription = "بينكي برايم",
                                            tint = Color(0xFFD4AF37),
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Text(
                                            text = "بينكي برايم 👑",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = Color(0xFFB8860B)
                                        )
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = Formatters.formatOrderDate(order.createdAt),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_order_detail_btn")) {
                        Icon(Icons.Outlined.Close, contentDescription = "إغلاق")
                    }
                }

                Divider(color = MaterialTheme.colorScheme.outlineVariant)

                // Scrollable Content
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(vertical = 16.dp)
                ) {
                    // Profit & Stats Highlights Card
                    if (order.profit != 0.0) {
                        item {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF10B981).copy(alpha = 0.08f)),
                                border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.25f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(Color(0xFF10B981).copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.TrendingUp,
                                            contentDescription = null,
                                            tint = Color(0xFF10B981)
                                        )
                                    }
                                    Column {
                                        Text(
                                            text = "صافي الأرباح من هذا الطلب",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = Color(0xFF047857)
                                        )
                                        Text(
                                            text = Formatters.formatCurrencyEgp(order.profit),
                                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                            color = Color(0xFF065F46)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Coupon Details Code Card
                    if (order.couponCode.isNotEmpty()) {
                        item {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = PinkPrimary.copy(alpha = 0.05f)),
                                border = BorderStroke(1.dp, PinkPrimary.copy(alpha = 0.2f))
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.CardGiftcard,
                                            contentDescription = null,
                                            tint = PinkPrimary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = "تم استخدام كوبون خصم حقيقي",
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                            color = PinkPrimary
                                        )
                                    }
                                    
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("رمز الكوبون:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = PinkPrimary.copy(alpha = 0.1f),
                                            modifier = Modifier.padding(horizontal = 4.dp)
                                        ) {
                                            Text(
                                                text = order.couponCode,
                                                fontWeight = FontWeight.Bold,
                                                color = PinkPrimary,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                                fontSize = 12.sp
                                            )
                                        }
                                    }
                                    
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("قيمة خصم الكوبون:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(
                                            text = Formatters.formatCurrencyEgp(order.couponDiscount),
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF10B981)
                                        )
                                    }

                                    if (order.couponFreeShipping) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.LocalShipping,
                                                contentDescription = null,
                                                tint = Color(0xFF10B981),
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Text(
                                                text = "الشحن مجاني بالكامل بفضل هذا الكوبون 🎁",
                                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                                color = Color(0xFF047857)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Status change section
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                            border = CardDefaults.outlinedCardBorder()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "حالة الطلب الحالية:",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    OrderStatusBadge(status = order.status)
                                }

                                Text(
                                    text = "تحديث حالة الطلب لمزامنة البيانات فورا مع متجر بينكي والعميل:",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                var dropdownExpanded by remember { mutableStateOf(false) }

                                ExposedDropdownMenuBox(
                                    expanded = dropdownExpanded,
                                    onExpandedChange = { dropdownExpanded = !dropdownExpanded }
                                ) {
                                    OutlinedTextField(
                                        value = selectedStatus.arabicLabel,
                                        onValueChange = {},
                                        readOnly = true,
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) },
                                        modifier = Modifier
                                            .menuAnchor()
                                            .fillMaxWidth()
                                            .testTag("status_selector_field"),
                                        shape = RoundedCornerShape(12.dp)
                                    )

                                    ExposedDropdownMenu(
                                        expanded = dropdownExpanded,
                                        onDismissRequest = { dropdownExpanded = false }
                                    ) {
                                        OrderStatus.entries.forEach { status ->
                                            DropdownMenuItem(
                                                text = { Text(status.arabicLabel) },
                                                onClick = {
                                                    selectedStatus = status
                                                    dropdownExpanded = false
                                                    onStatusChange(status)
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Customer Information & Quick Contact
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = CardDefaults.outlinedCardBorder()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(
                                    text = "بيانات العميل وعنوان الشحن بالتفصيل",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(
                                            text = order.customerName,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodyLarge
                                        )
                                        Text(
                                            text = "الهاتف: ${order.customerPhone}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "المحافظة: ${order.governorate}",
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            text = "المركز/المدينة: ${order.shippingCenter}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = PinkPrimary
                                        )
                                        Text(
                                            text = "العنوان بالتفصيل: ${order.customerAddress}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    // Direct Contact Actions
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        // Call Button
                                        IconButton(
                                            onClick = {
                                                val callIntent = Intent(Intent.ACTION_DIAL).apply {
                                                    data = Uri.parse("tel:${order.customerPhone}")
                                                }
                                                context.startActivity(callIntent)
                                            },
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(PinkPrimary.copy(alpha = 0.12f))
                                                .size(44.dp)
                                                .testTag("call_customer_btn")
                                        ) {
                                            Icon(Icons.Outlined.Phone, contentDescription = "اتصال بالعميل", tint = PinkPrimary)
                                        }

                                        // WhatsApp Button
                                        IconButton(
                                            onClick = {
                                                val cleanPhone = order.customerPhone.replace("+", "").replace(" ", "")
                                                val formatted = if (cleanPhone.startsWith("01")) "2$cleanPhone" else cleanPhone
                                                val waIntent = Intent(Intent.ACTION_VIEW).apply {
                                                    data = Uri.parse("https://api.whatsapp.com/send?phone=$formatted&text=مرحباً ${order.customerName}، بخصوص طلبك رقم #${order.orderNumber} من متجر بينكي")
                                                }
                                                context.startActivity(waIntent)
                                            },
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(Color(0xFF25D366).copy(alpha = 0.12f))
                                                .size(44.dp)
                                                .testTag("whatsapp_customer_btn")
                                        ) {
                                            Icon(Icons.Outlined.Chat, contentDescription = "واتساب", tint = Color(0xFF25D366))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Order Items Table
                    item {
                        Text(
                            text = "المنتجات والأصناف المطلوبة (${order.items.size})",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    items(order.items, key = { it.id }) { item ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                            border = CardDefaults.outlinedCardBorder()
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(item.productName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    
                                    val attributes = listOfNotNull(
                                        if (item.variantName.isNullOrEmpty()) null else "النوع: ${item.variantName}",
                                        if (item.color.isNullOrEmpty()) null else "اللون: ${item.color}",
                                        if (item.size.isNullOrEmpty()) null else "المقاس: ${item.size}"
                                    )
                                    if (attributes.isNotEmpty()) {
                                        Text(
                                            text = attributes.joinToString(" • "),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    
                                    Text(
                                        text = "${item.quantity} قطعة × ${Formatters.formatCurrencyEgp(item.unitPrice)}",
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                        color = PinkPrimary
                                    )
                                }

                                Text(
                                    text = Formatters.formatCurrencyEgp(item.lineTotal),
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    // Financial Summary Card
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = CardDefaults.outlinedCardBorder()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text("ملخص ومكونات الحساب", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("المجموع الفرعي للمنتجات:", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(Formatters.formatCurrencyEgp(order.subtotalAmount))
                                }

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("تكلفة الشحن لـ ${order.governorate}:", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(Formatters.formatCurrencyEgp(order.shippingFee))
                                }

                                if (order.discountAmount > 0) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("إجمالي الخصم:", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("- ${Formatters.formatCurrencyEgp(order.discountAmount)}", color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                                    }
                                }

                                Divider(color = MaterialTheme.colorScheme.outlineVariant)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("المبلغ الإجمالي المستحق:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                                    Text(
                                        text = Formatters.formatCurrencyEgp(order.totalAmount),
                                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                                        color = PinkPrimary
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("طريقة الدفع الفعّالة:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${order.paymentMethod.arabicLabel} (${order.paymentStatus.arabicLabel})", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }

                    // Internal Notes TextField
                    item {
                        OutlinedTextField(
                            value = noteText,
                            onValueChange = { noteText = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("order_notes_input"),
                            label = { Text("ملاحظات داخلية وتعليمات فريق العمل") },
                            placeholder = { Text("مثال: يرجى المتابعة وتأكيد العنوان مع العميل بعد الظهر...") },
                            shape = RoundedCornerShape(12.dp),
                            minLines = 3
                        )
                    }
                }

                // Footer Actions
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            onStatusChange(selectedStatus)
                            onDismiss()
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PinkPrimary, contentColor = Color(0xFF381528)),
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("save_order_status_btn")
                    ) {
                        Text("حفظ التغييرات والمزامنة", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dismiss_order_btn")
                    ) {
                        Text("إغلاق")
                    }
                }
            }
        }
    }
}
