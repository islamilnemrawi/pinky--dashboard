package com.pinky.dashboard.data.local

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import java.io.IOException
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Context.authDataStore: DataStore<Preferences> by preferencesDataStore(name = "pinky_auth_preferences")

class AuthDataStoreManager(private val context: Context) {

    companion object {
        private const val KEY_ALIAS = "elory_dashboard_auth_v1"
        private const val ENCRYPTED_PREFIX = "enc:"
        private const val GCM_TAG_LENGTH_BITS = 128
        private val KEY_ACCESS_TOKEN = stringPreferencesKey("access_token")
        private val KEY_REFRESH_TOKEN = stringPreferencesKey("refresh_token")
        private val KEY_EXPIRES_AT = longPreferencesKey("expires_at")
        private val KEY_USER_ID = stringPreferencesKey("user_id")
        private val KEY_USER_NAME = stringPreferencesKey("user_name")
        private val KEY_USER_EMAIL = stringPreferencesKey("user_email")
        private val KEY_USER_ROLE = stringPreferencesKey("user_role")
        private val KEY_USER_PERMISSIONS = stringPreferencesKey("user_permissions")
    }

    data class Session(
        val accessToken: String?,
        val refreshToken: String?,
        val expiresAt: Long,
        val userId: String?,
        val userName: String?,
        val userEmail: String?,
        val userRole: String?,
        val userPermissions: String?
    )

    val sessionFlow: Flow<Session> = context.authDataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            Session(
                accessToken = decryptIfNeeded(preferences[KEY_ACCESS_TOKEN]),
                refreshToken = decryptIfNeeded(preferences[KEY_REFRESH_TOKEN]),
                expiresAt = preferences[KEY_EXPIRES_AT] ?: 0L,
                userId = preferences[KEY_USER_ID],
                userName = preferences[KEY_USER_NAME],
                userEmail = preferences[KEY_USER_EMAIL],
                userRole = preferences[KEY_USER_ROLE],
                userPermissions = preferences[KEY_USER_PERMISSIONS]
            )
        }

    suspend fun getSession(): Session {
        val preferences = context.authDataStore.data.first()
        val accessRaw = preferences[KEY_ACCESS_TOKEN]
        val refreshRaw = preferences[KEY_REFRESH_TOKEN]
        val session = Session(
            accessToken = decryptIfNeeded(accessRaw),
            refreshToken = decryptIfNeeded(refreshRaw),
            expiresAt = preferences[KEY_EXPIRES_AT] ?: 0L,
            userId = preferences[KEY_USER_ID],
            userName = preferences[KEY_USER_NAME],
            userEmail = preferences[KEY_USER_EMAIL],
            userRole = preferences[KEY_USER_ROLE],
            userPermissions = preferences[KEY_USER_PERMISSIONS]
        )
        // Migrate sessions written by previous app versions from plaintext to Keystore encryption.
        if (accessRaw != null && !accessRaw.startsWith(ENCRYPTED_PREFIX) && !session.accessToken.isNullOrBlank()) {
            context.authDataStore.edit { prefs -> prefs[KEY_ACCESS_TOKEN] = encrypt(session.accessToken) }
        }
        if (refreshRaw != null && !refreshRaw.startsWith(ENCRYPTED_PREFIX) && !session.refreshToken.isNullOrBlank()) {
            context.authDataStore.edit { prefs -> prefs[KEY_REFRESH_TOKEN] = encrypt(session.refreshToken) }
        }
        return session
    }

    suspend fun saveSession(
        accessToken: String,
        refreshToken: String?,
        expiresAt: Long,
        userId: String,
        userName: String,
        userEmail: String,
        userRole: String,
        userPermissions: String = ""
    ) {
        context.authDataStore.edit { preferences ->
            preferences[KEY_ACCESS_TOKEN] = encrypt(accessToken)
            if (!refreshToken.isNullOrBlank()) preferences[KEY_REFRESH_TOKEN] = encrypt(refreshToken)
            else preferences.remove(KEY_REFRESH_TOKEN)
            preferences[KEY_EXPIRES_AT] = expiresAt
            preferences[KEY_USER_ID] = userId
            preferences[KEY_USER_NAME] = userName
            preferences[KEY_USER_EMAIL] = userEmail
            preferences[KEY_USER_ROLE] = userRole
            preferences[KEY_USER_PERMISSIONS] = userPermissions
        }
    }

    suspend fun updateTokens(accessToken: String, refreshToken: String, expiresAt: Long) {
        context.authDataStore.edit { preferences ->
            preferences[KEY_ACCESS_TOKEN] = encrypt(accessToken)
            preferences[KEY_REFRESH_TOKEN] = encrypt(refreshToken)
            preferences[KEY_EXPIRES_AT] = expiresAt
        }
    }

    suspend fun clearSession() {
        context.authDataStore.edit { it.clear() }
    }

    private fun decryptIfNeeded(value: String?): String? {
        if (value.isNullOrBlank()) return null
        if (!value.startsWith(ENCRYPTED_PREFIX)) return value // one-time legacy plaintext migration
        return runCatching {
            val payload = Base64.decode(value.removePrefix(ENCRYPTED_PREFIX), Base64.NO_WRAP)
            require(payload.size > 12) { "Invalid encrypted session payload" }
            val iv = payload.copyOfRange(0, 12)
            val encrypted = payload.copyOfRange(12, payload.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))
            String(cipher.doFinal(encrypted), Charsets.UTF_8)
        }.getOrNull()
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val payload = cipher.iv + encrypted
        return ENCRYPTED_PREFIX + Base64.encodeToString(payload, Base64.NO_WRAP)
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }
}
