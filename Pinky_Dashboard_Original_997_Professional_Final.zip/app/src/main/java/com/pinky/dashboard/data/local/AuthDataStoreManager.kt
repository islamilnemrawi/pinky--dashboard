package com.pinky.dashboard.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.authDataStore: DataStore<Preferences> by preferencesDataStore(name = "pinky_auth_preferences")

class AuthDataStoreManager(private val context: Context) {

    companion object {
        private val KEY_ACCESS_TOKEN = stringPreferencesKey("access_token")
        private val KEY_REFRESH_TOKEN = stringPreferencesKey("refresh_token")
        private val KEY_EXPIRES_AT = longPreferencesKey("expires_at")
        private val KEY_USER_ID = stringPreferencesKey("user_id")
        private val KEY_USER_NAME = stringPreferencesKey("user_name")
        private val KEY_USER_EMAIL = stringPreferencesKey("user_email")
        private val KEY_USER_ROLE = stringPreferencesKey("user_role")
    }

    data class Session(
        val accessToken: String?,
        val refreshToken: String?,
        val expiresAt: Long,
        val userId: String?,
        val userName: String?,
        val userEmail: String?,
        val userRole: String?
    )

    val sessionFlow: Flow<Session> = context.authDataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { preferences ->
            Session(
                accessToken = preferences[KEY_ACCESS_TOKEN],
                refreshToken = preferences[KEY_REFRESH_TOKEN],
                expiresAt = preferences[KEY_EXPIRES_AT] ?: 0L,
                userId = preferences[KEY_USER_ID],
                userName = preferences[KEY_USER_NAME],
                userEmail = preferences[KEY_USER_EMAIL],
                userRole = preferences[KEY_USER_ROLE]
            )
        }

    suspend fun getSession(): Session {
        return sessionFlow.firstOrNull() ?: Session(null, null, 0L, null, null, null, null)
    }

    suspend fun saveSession(
        accessToken: String,
        refreshToken: String?,
        expiresAt: Long,
        userId: String,
        userName: String,
        userEmail: String,
        userRole: String
    ) {
        context.authDataStore.edit { preferences ->
            preferences[KEY_ACCESS_TOKEN] = accessToken
            if (refreshToken != null) {
                preferences[KEY_REFRESH_TOKEN] = refreshToken
            }
            preferences[KEY_EXPIRES_AT] = expiresAt
            preferences[KEY_USER_ID] = userId
            preferences[KEY_USER_NAME] = userName
            preferences[KEY_USER_EMAIL] = userEmail
            preferences[KEY_USER_ROLE] = userRole
        }
    }

    suspend fun updateTokens(accessToken: String, refreshToken: String, expiresAt: Long) {
        context.authDataStore.edit { preferences ->
            preferences[KEY_ACCESS_TOKEN] = accessToken
            preferences[KEY_REFRESH_TOKEN] = refreshToken
            preferences[KEY_EXPIRES_AT] = expiresAt
        }
    }

    suspend fun clearSession() {
        context.authDataStore.edit { preferences ->
            preferences.clear()
        }
    }
}
