-- Pinky Dashboard backend hardening / verification migration
-- Idempotent. Run this in the Supabase SQL Editor for the Pinky project.
-- This does not create fake store data and does not modify existing product/order data.

-- Public storefront reads remain possible, but anonymous users must never be
-- able to write dashboard configuration directly.
DO $$
BEGIN
    IF to_regclass('public.site_customizations') IS NOT NULL THEN
        REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON public.site_customizations FROM anon;
        GRANT SELECT ON public.site_customizations TO anon;
    END IF;

    IF to_regclass('public.store_settings') IS NOT NULL THEN
        REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON public.store_settings FROM anon;
        GRANT SELECT ON public.store_settings TO anon;
    END IF;
END;
$$;

-- Ensure normalized order items can be read by authenticated dashboard staff.
DO $$
BEGIN
    IF to_regclass('public.order_items') IS NOT NULL THEN
        ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
        DROP POLICY IF EXISTS pinky_dashboard_select_order_items ON public.order_items;
        CREATE POLICY pinky_dashboard_select_order_items
            ON public.order_items
            FOR SELECT TO authenticated
            USING (
                public.has_staff_permission('MANAGE_ORDERS')
                OR public.has_staff_permission('UPDATE_ORDER_STATUS')
            );
    END IF;
END;
$$;

-- Verify the core tables exist. The SELECT result is intentionally diagnostic only.
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
  AND table_name IN (
      'categories', 'products', 'catalog_products', 'orders', 'order_items',
      'customers', 'shipping_governorates', 'shipping_centers',
      'offers', 'banners', 'site_customizations', 'store_settings'
  )
ORDER BY table_name;

-- Quick row-count diagnostics. These do not modify data.
SELECT
    (SELECT count(*) FROM public.categories) AS categories_count,
    (SELECT count(*) FROM public.orders) AS orders_count,
    (SELECT count(*) FROM public.order_items) AS order_items_count,
    (SELECT count(*) FROM public.shipping_governorates) AS governorates_count,
    (SELECT count(*) FROM public.shipping_centers) AS shipping_centers_count,
    (SELECT count(*) FROM public.banners) AS banners_count,
    (SELECT count(*) FROM public.site_customizations) AS site_customizations_count;
