<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/420277e8-866f-4ea1-b583-97b3e7a3c765

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.

## Pinky backend / AI setup

The Android dashboard is server-first: Supabase is the source of truth for the store, dashboard and order data. The local Room database is only a cache.

Before running the app, create a local `.env` file beside `settings.gradle.kts` (do not commit it) and provide the real Supabase anon key already belonging to the Pinky store project:

```text
SUPABASE_URL=https://qhqyptilvbecutfxwxsu.supabase.co
SUPABASE_ANON_KEY=YOUR_REAL_SUPABASE_ANON_KEY
```

The in-dashboard AI can answer general questions through Gemini when `GEMINI_API_KEY` is configured. If it is not configured, the existing local store-data assistant remains available.

```text
GEMINI_API_KEY=YOUR_GEMINI_API_KEY
GEMINI_MODEL=gemini-3.8-flash
```

Never put a Supabase `service_role` key in the Android app.
