-- PINKY STORE <-> PINKY DASHBOARD - FINAL SYNC / RLS / SEED MIGRATION
-- Run once in Supabase SQL Editor. Safe to run again.
-- No service_role key is required in the Android app.

begin;

create extension if not exists pgcrypto;

-- ------------------------------------------------------------
-- 1) Required compatibility columns
-- ------------------------------------------------------------
alter table public.products add column if not exists wholesale_price numeric(12,2) default 0;
alter table public.products add column if not exists code text;
alter table public.products add column if not exists stock integer not null default 0;
alter table public.products add column if not exists discount numeric(5,2) default 0;
alter table public.products add column if not exists featured boolean not null default false;
alter table public.products add column if not exists active boolean not null default true;
alter table public.products add column if not exists colors jsonb;
alter table public.products add column if not exists sizes jsonb;
alter table public.products add column if not exists variants jsonb;
alter table public.products add column if not exists gallery jsonb;
alter table public.products add column if not exists color_options jsonb;

alter table public.staff_profiles add column if not exists email text;
alter table public.staff_profiles add column if not exists name text;
alter table public.staff_profiles add column if not exists role text not null default 'staff';
alter table public.staff_profiles add column if not exists permissions jsonb not null default '{}'::jsonb;
alter table public.staff_profiles add column if not exists active boolean not null default true;
alter table public.staff_profiles add column if not exists created_at timestamptz not null default now();
alter table public.staff_profiles add column if not exists updated_at timestamptz not null default now();

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text,
  image text,
  sort_order integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.shipping_governorates (
  governorate text primary key,
  price numeric(12,2) not null default 0,
  active boolean not null default true,
  centers_enabled boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.shipping_centers (
  id uuid primary key default gen_random_uuid(),
  governorate text not null,
  center text not null,
  price numeric(12,2) not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.site_customizations (
  id integer primary key default 1,
  config jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
insert into public.site_customizations(id) values (1) on conflict (id) do nothing;

create table if not exists public.store_settings (
  id integer primary key default 1,
  store_name text default 'Pinky',
  whatsapp text,
  instagram text,
  facebook text,
  logo text,
  updated_at timestamptz not null default now()
);
insert into public.store_settings(id,store_name) values (1,'Pinky') on conflict (id) do nothing;

-- ------------------------------------------------------------
-- 2) The seven real store categories currently shown by the site
-- ------------------------------------------------------------
insert into public.categories(name,slug,image,sort_order,active)
select * from (values
  ('لانجري','lingerie','https://images.unsplash.com/photo-1596755389378-c31d21fd1273?auto=format&fit=crop&w=600&q=80',1,true),
  ('اكسسوارات','accessories','https://images.unsplash.com/photo-1611652022419-a9419f74343d?auto=format&fit=crop&w=600&q=80',2,true),
  ('ساعات حريمي','women-watches','https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=600&q=80',3,true),
  ('ساعات رجالي','men-watches','https://images.unsplash.com/photo-1523170335258-f5ed11844a49?auto=format&fit=crop&w=600&q=80',4,true),
  ('شنط حريمي','women-bags','https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?auto=format&fit=crop&w=600&q=80',5,true),
  ('شنط مدارس','school-bags','https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=600&q=80',6,true),
  ('مكياج','makeup','https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=600&q=80',7,true)
) as seed(name,slug,image,sort_order,active)
where not exists (select 1 from public.categories c where lower(trim(c.name))=lower(trim(seed.name)));

-- ------------------------------------------------------------
-- 3) Public catalog view = exactly what the customer site reads
-- ------------------------------------------------------------
create or replace view public.catalog_products
with (security_invoker = false)
as
select id,name,description,image,category,price,old_price,discount,featured,active,colors,color_options,sizes,variants,gallery,created_at
from public.products
where active = true;

grant select on public.catalog_products to anon, authenticated;

-- ------------------------------------------------------------
-- 4) Permission helpers. Owner is recognized even if a staff row
--    was missing before this migration.
-- ------------------------------------------------------------
create or replace function public.is_elora_staff()
returns boolean
language plpgsql
security definer
stable
set search_path = public, auth, pg_catalog
as $$
declare
  uid uuid := auth.uid();
  mail text := lower(coalesce(auth.jwt()->>'email',''));
  r text;
  a boolean;
begin
  if uid is null then return false; end if;
  if uid = '50fefcea-5eab-44bd-80f9-9675648c6ec7'::uuid then return true; end if;
  if mail in ('ilnemrawi@gmail.com','ilnemrawy@gmail.com','islamilnemrawi222@gmail.com') then return true; end if;
  select lower(coalesce(role,'staff')), coalesce(active,true) into r,a
  from public.staff_profiles where id=uid limit 1;
  return coalesce(a,false) and r in ('owner','admin','manager','staff','employee');
exception when others then return false;
end;
$$;

create or replace function public.has_staff_permission(required_permission text)
returns boolean
language plpgsql
security definer
stable
set search_path = public, auth, pg_catalog
as $$
declare
  uid uuid := auth.uid();
  mail text := lower(coalesce(auth.jwt()->>'email',''));
  r text;
  a boolean;
  p jsonb;
  wanted text := lower(coalesce(required_permission,''));
  legacy text := upper(replace(wanted,'.','_'));
  v jsonb;
begin
  if uid is null then return false; end if;
  if uid = '50fefcea-5eab-44bd-80f9-9675648c6ec7'::uuid then return true; end if;
  if mail in ('ilnemrawi@gmail.com','ilnemrawy@gmail.com','islamilnemrawi222@gmail.com') then return true; end if;

  select lower(coalesce(role,'staff')), coalesce(active,true), coalesce(permissions,'{}'::jsonb)
    into r,a,p
  from public.staff_profiles where id=uid limit 1;

  if not coalesce(a,false) then return false; end if;
  if r in ('owner','admin','manager') then return true; end if;

  v := p;
  if jsonb_typeof(v) = 'object' then
    if coalesce((v -> wanted)::boolean,false) then return true; end if;
    if coalesce((v -> legacy)::boolean,false) then return true; end if;
    if coalesce((v ->> wanted),'') = 'true' then return true; end if;
    if coalesce((v ->> legacy),'') = 'true' then return true; end if;
  end if;

  return false;
exception when others then return false;
end;
$$;

grant execute on function public.is_elora_staff() to anon, authenticated;
grant execute on function public.has_staff_permission(text) to authenticated;

-- ------------------------------------------------------------
-- 5) Fix the missing owner profile shown by Health Check.
-- ------------------------------------------------------------
insert into public.staff_profiles(id,email,name,role,permissions,active,updated_at)
select u.id, lower(u.email), coalesce(u.raw_user_meta_data->>'full_name','إسلام النمراوي (المالك)'), 'owner', '{}'::jsonb, true, now()
from auth.users u
where u.id='50fefcea-5eab-44bd-80f9-9675648c6ec7'::uuid
  and not exists (select 1 from public.staff_profiles sp where sp.id=u.id);

-- ------------------------------------------------------------
-- 6) RLS / GRANTS
-- ------------------------------------------------------------

-- Categories
alter table public.categories enable row level security;
drop policy if exists pinky_categories_public_read on public.categories;
drop policy if exists pinky_categories_staff_write on public.categories;
create policy pinky_categories_public_read on public.categories for select to anon, authenticated using (true);
create policy pinky_categories_staff_write on public.categories for all to authenticated
using (public.is_elora_staff()) with check (public.is_elora_staff());
grant select on public.categories to anon, authenticated;
grant insert,update,delete on public.categories to authenticated;

-- Products
alter table public.products enable row level security;
drop policy if exists pinky_products_public_read on public.products;
drop policy if exists pinky_products_staff_write on public.products;
create policy pinky_products_public_read on public.products for select to anon using (active=true);
create policy pinky_products_staff_write on public.products for all to authenticated
using (public.is_elora_staff()) with check (public.is_elora_staff());
grant select on public.products to anon, authenticated;
grant insert,update,delete on public.products to authenticated;

-- Orders: customers can create orders; dashboard staff can read/update.
alter table public.orders enable row level security;
drop policy if exists pinky_orders_guest_insert on public.orders;
drop policy if exists pinky_orders_staff_manage on public.orders;
create policy pinky_orders_guest_insert on public.orders for insert to anon, authenticated with check (true);
create policy pinky_orders_staff_manage on public.orders for all to authenticated
using (public.is_elora_staff()) with check (public.is_elora_staff());
grant insert on public.orders to anon, authenticated;
grant select,update,delete on public.orders to authenticated;

-- Order items are dashboard-read data when a normalized table exists.
do $$ begin
  if to_regclass('public.order_items') is not null then
    alter table public.order_items enable row level security;
    execute 'drop policy if exists pinky_order_items_staff_read on public.order_items';
    execute 'create policy pinky_order_items_staff_read on public.order_items for select to authenticated using (public.is_elora_staff())';
    execute 'grant select on public.order_items to authenticated';
  end if;
end $$;

-- Shipping
do $$ begin
  if to_regclass('public.shipping_governorates') is not null then
    alter table public.shipping_governorates enable row level security;
    drop policy if exists pinky_shipping_gov_public_read on public.shipping_governorates;
    drop policy if exists pinky_shipping_gov_staff_write on public.shipping_governorates;
    create policy pinky_shipping_gov_public_read on public.shipping_governorates for select to anon, authenticated using (active=true);
    create policy pinky_shipping_gov_staff_write on public.shipping_governorates for all to authenticated using (public.is_elora_staff()) with check (public.is_elora_staff());
    grant select on public.shipping_governorates to anon, authenticated;
    grant insert,update,delete on public.shipping_governorates to authenticated;
  end if;
  if to_regclass('public.shipping_centers') is not null then
    alter table public.shipping_centers enable row level security;
    drop policy if exists pinky_shipping_center_public_read on public.shipping_centers;
    drop policy if exists pinky_shipping_center_staff_write on public.shipping_centers;
    create policy pinky_shipping_center_public_read on public.shipping_centers for select to anon, authenticated using (active=true);
    create policy pinky_shipping_center_staff_write on public.shipping_centers for all to authenticated using (public.is_elora_staff()) with check (public.is_elora_staff());
    grant select on public.shipping_centers to anon, authenticated;
    grant insert,update,delete on public.shipping_centers to authenticated;
  end if;
end $$;

-- Site settings / visual customization
alter table public.site_customizations enable row level security;
drop policy if exists pinky_site_public_read on public.site_customizations;
drop policy if exists pinky_site_staff_write on public.site_customizations;
create policy pinky_site_public_read on public.site_customizations for select to anon, authenticated using (true);
create policy pinky_site_staff_write on public.site_customizations for all to authenticated using (public.is_elora_staff()) with check (public.is_elora_staff());
grant select on public.site_customizations to anon, authenticated;
grant insert,update,delete on public.site_customizations to authenticated;

alter table public.store_settings enable row level security;
drop policy if exists pinky_settings_public_read on public.store_settings;
drop policy if exists pinky_settings_staff_write on public.store_settings;
create policy pinky_settings_public_read on public.store_settings for select to anon, authenticated using (true);
create policy pinky_settings_staff_write on public.store_settings for all to authenticated using (public.is_elora_staff()) with check (public.is_elora_staff());
grant select on public.store_settings to anon, authenticated;
grant insert,update,delete on public.store_settings to authenticated;

-- Offers and banners if present
do $$ begin
  if to_regclass('public.offers') is not null then
    alter table public.offers enable row level security;
    drop policy if exists pinky_offers_public_read on public.offers;
    drop policy if exists pinky_offers_staff_write on public.offers;
    create policy pinky_offers_public_read on public.offers for select to anon, authenticated using (coalesce(active,true)=true);
    create policy pinky_offers_staff_write on public.offers for all to authenticated using (public.is_elora_staff()) with check (public.is_elora_staff());
    grant select on public.offers to anon, authenticated;
    grant insert,update,delete on public.offers to authenticated;
  end if;
  if to_regclass('public.banners') is not null then
    alter table public.banners enable row level security;
    drop policy if exists pinky_banners_public_read on public.banners;
    drop policy if exists pinky_banners_staff_write on public.banners;
    create policy pinky_banners_public_read on public.banners for select to anon, authenticated using (coalesce(active,true)=true);
    create policy pinky_banners_staff_write on public.banners for all to authenticated using (public.is_elora_staff()) with check (public.is_elora_staff());
    grant select on public.banners to anon, authenticated;
    grant insert,update,delete on public.banners to authenticated;
  end if;
end $$;

-- Customers are dashboard data; no customer PII is exposed to anon.
do $$ begin
  if to_regclass('public.customers') is not null then
    alter table public.customers enable row level security;
    drop policy if exists pinky_customers_staff on public.customers;
    create policy pinky_customers_staff on public.customers for all to authenticated using (public.is_elora_staff()) with check (public.is_elora_staff());
    grant select,insert,update,delete on public.customers to authenticated;
  end if;
end $$;

commit;

-- After running this migration, reopen Pinky Dashboard and press the refresh icon.
