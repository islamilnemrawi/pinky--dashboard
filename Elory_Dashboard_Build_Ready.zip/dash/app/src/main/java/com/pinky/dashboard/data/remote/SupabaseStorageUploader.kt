package com.pinky.dashboard.data.remote

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.UUID

/** Uploads selected product media to the same public Supabase bucket used by the storefront. */
object SupabaseStorageUploader {
    private const val MAX_IMAGE_DIMENSION = 1600
    private const val WEBP_QUALITY = 82

    suspend fun uploadProductImage(
        contentResolver: ContentResolver,
        uri: Uri,
        productId: String,
        label: String
    ): String = withContext(Dispatchers.IO) {
        check(SupabaseClient.hasValidConfiguration) { "إعدادات الاتصال بقاعدة البيانات غير مكتملة." }
        check(SupabaseClient.isAuthenticated && !SupabaseClient.accessToken.isNullOrBlank()) {
            "يجب تسجيل الدخول بحساب لديه صلاحية إدارة المنتجات قبل رفع الصور."
        }

        val safeProductId = productId.replace(Regex("[^A-Za-z0-9_-]"), "_").take(80).ifBlank { "product" }
        val safeLabel = label.replace(Regex("[^A-Za-z0-9_-]"), "_").take(24).ifBlank { "image" }
        val objectPath = "$safeProductId/${safeLabel}_${UUID.randomUUID()}.webp"
        val imageBytes = readAndCompress(contentResolver, uri)
        val requestBody = imageBytes.toRequestBody("image/webp".toMediaType())

        val response = SupabaseClient.service.uploadStorageFile(
            bucket = SupabaseConfig.BUCKET_PRODUCT_IMAGES,
            path = objectPath,
            file = requestBody,
            contentType = "image/webp",
            upsert = "false"
        )
        if (!response.isSuccessful) {
            throw IOException("فشل رفع الصورة إلى التخزين (HTTP ${response.code()}). تحقق من صلاحية إدارة المنتجات وإعدادات Storage.")
        }

        "${SupabaseClient.supabaseUrl}/storage/v1/object/public/${SupabaseConfig.BUCKET_PRODUCT_IMAGES}/$objectPath"
    }

    private fun readAndCompress(contentResolver: ContentResolver, uri: Uri): ByteArray {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { input -> BitmapFactory.decodeStream(input, null, bounds) }
            ?: throw IOException("تعذر فتح ملف الصورة المحدد.")
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IOException("ملف الصورة غير صالح.")

        var sampleSize = 1
        while (bounds.outWidth / sampleSize > MAX_IMAGE_DIMENSION * 2 ||
            bounds.outHeight / sampleSize > MAX_IMAGE_DIMENSION * 2) {
            sampleSize *= 2
        }
        val options = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val bitmap = contentResolver.openInputStream(uri)?.use { input -> BitmapFactory.decodeStream(input, null, options) }
            ?: throw IOException("تعذر قراءة الصورة من الهاتف.")

        val scaled = try {
            val maxDimension = maxOf(bitmap.width, bitmap.height)
            if (maxDimension > MAX_IMAGE_DIMENSION) {
                val factor = MAX_IMAGE_DIMENSION.toFloat() / maxDimension.toFloat()
                Bitmap.createScaledBitmap(
                    bitmap,
                    (bitmap.width * factor).toInt().coerceAtLeast(1),
                    (bitmap.height * factor).toInt().coerceAtLeast(1),
                    true
                ).also { if (it !== bitmap) bitmap.recycle() }
            } else bitmap
        } catch (e: Exception) {
            bitmap.recycle()
            throw IOException("تعذر تجهيز الصورة للرفع.", e)
        }

        return try {
            ByteArrayOutputStream().use { output ->
                val format = if (android.os.Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                if (!scaled.compress(format, WEBP_QUALITY, output)) throw IOException("تعذر ضغط الصورة.")
                output.toByteArray()
            }
        } finally {
            scaled.recycle()
        }
    }
}
