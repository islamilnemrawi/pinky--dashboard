# Elory Dashboard (Android)

This is the Android administration app for the existing Elory storefront. The Android application ID and Kotlin package are intentionally kept as `com.pinky.dashboard` so an updated APK can replace an older installation without creating a second app identity. The visible app branding is Elory.

## Backend connection

The app connects to the same Supabase project as the Elory website:

- Project URL: `https://dmttevcncsxzbamazmmq.supabase.co`
- Client key: the public `sb_publishable_...` key used by the storefront
- Authentication: Supabase Auth user login, followed by an active `staff_profiles` row whose `id` equals the authenticated user's UUID
- Authorization: exact permission keys from the staff profile; the owner role is recognized only from an active profile row

Never add a Supabase secret/service-role key or a staff password to this Android project. The publishable key is public and relies on RLS for data authorization.

## Required Supabase setup

Before first use of the dashboard's staff login or media uploads, review and run `elory_security_storage_migration.sql` in the Supabase SQL Editor. This is a database change and cannot be applied remotely by the APK build. The migration:

- removes hard-coded owner UUID/email authorization bypasses;
- uses the authenticated user's active staff profile and exact JSONB/legacy permission keys;
- protects staff, customer, orders, products, categories, offers, banners, coupons, shipping, prime, website, and device tables with role-based policies;
- restricts public customer inserts to basic name/phone validation while blocking public customer reads;
- preserves anonymous order and order-item insertion required by the existing website checkout;
- keeps the existing `pinky-products` and `pinky-banners` bucket IDs and sets up public read plus role-limited uploads.

An owner account must already exist in Supabase Auth and have an active `staff_profiles` row with `role = 'owner'` and `id` equal to that Auth user's UUID. The first owner must be bootstrapped manually in the Supabase SQL Editor (the application deliberately has no embedded owner password or privilege bypass):

```sql
-- Replace the values before running. Get the UUID from Authentication > Users.
INSERT INTO public.staff_profiles (id, name, email, role, permissions, active)
VALUES (
  'REPLACE-WITH-AUTH-USER-UUID'::uuid,
  'Elory Owner',
  'REPLACE-WITH-THE-SAME-AUTH-EMAIL',
  'owner',
  '{}'::jsonb,
  true
)
ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  email = EXCLUDED.email,
  role = 'owner',
  active = true;
```

Do not grant owner by email or hard-coded UUID. For other employees, create the user first under Supabase Authentication, then add a profile from the dashboard using that user's exact Auth UID and matching email. Only an existing owner can assign the owner role.

## Build

1. Open this directory in Android Studio, or install Gradle 9.3.1 and Android SDK 36.
2. Copy `.env.example` to `.env` if you need to override the default project URL/publishable key or provide a Gemini API key.
3. Run `gradle :app:testDebugUnitTest :app:assembleDebug`.
4. The installable debug APK is generated under `app/build/outputs/apk/debug/`.

The repository GitHub Actions workflow also tests and builds the APK and publishes it as the `Elory-Dashboard-APK` artifact. It does not embed an owner password or elevated Supabase key.

## Security and compatibility notes

- Auth access/refresh tokens are encrypted using Android Keystore AES-GCM.
- Android app backup is disabled to avoid exporting authentication state.
- HTTP body logging is disabled; Authorization and API key headers are redacted.
- Images uploaded from the product editor are compressed to WebP and uploaded to the existing Supabase Storage product bucket; the returned public URL is saved with the product.
- Product list synchronization is paginated and only replaces the local cache after all pages load successfully.
- Dates from Supabase are parsed as ISO-8601 or legacy epoch values.
- Existing backend table names, storage bucket IDs, package name and application ID are retained for compatibility.
