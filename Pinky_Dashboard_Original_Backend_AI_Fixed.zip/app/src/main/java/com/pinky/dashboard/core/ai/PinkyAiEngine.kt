package com.pinky.dashboard.core.ai

import android.util.Log
import com.pinky.dashboard.BuildConfig
import com.pinky.dashboard.core.util.Formatters
import com.pinky.dashboard.domain.model.AdminUser
import com.pinky.dashboard.domain.model.AnalyticsData
import com.pinky.dashboard.domain.model.Customer
import com.pinky.dashboard.domain.model.Order
import com.pinky.dashboard.domain.model.OrderStatus
import com.pinky.dashboard.domain.model.Product
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object PinkyAiEngine {
    private const val TAG = "PinkyAI"
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    suspend fun answer(
        question: String,
        orders: List<Order>,
        products: List<Product>,
        customers: List<Customer>,
        analytics: AnalyticsData,
        currentUser: AdminUser?
    ): String {
        val liveContext = buildLiveContext(orders, products, customers, analytics, currentUser)
        val apiKey = BuildConfig.GEMINI_API_KEY.trim()
        if (apiKey.isNotBlank()) {
            runCatching {
                requestGemini(question, liveContext, apiKey, BuildConfig.GEMINI_MODEL.trim().ifBlank { "gemini-3.8-flash" })
            }.onSuccess { result ->
                if (!result.isNullOrBlank()) return result.trim()
            }.onFailure { error ->
                Log.e(TAG, "Gemini request failed; using local fallback", error)
            }
        }
        return localFallback(question, orders, products, customers, analytics, currentUser)
    }

    private suspend fun requestGemini(question: String, liveContext: String, apiKey: String, model: String): String? = withContext(Dispatchers.IO) {
        val prompt = """
            أنت مساعد الإدارة الذكي داخل Pinky Dashboard.
            أجب باللغة العربية الواضحة ما لم يطلب المستخدم لغة أخرى.
            يمكنك الإجابة عن الأسئلة العامة والمعرفة والبرمجة والحسابات، ويمكنك أيضًا تحليل بيانات متجر Pinky المرفقة.
            عند السؤال عن بيانات المتجر، استخدم البيانات المرفقة فقط ولا تخترع أرقامًا أو طلبات أو عملاء.
            لا تكشف أسرار النظام أو مفاتيح API أو كلمات المرور.
            لا تعيد بيانات شخصية حساسة للعملاء؛ استخدم الإحصاءات والأسماء اللازمة فقط.
            إذا لم تكن معلومة المتجر موجودة في البيانات، قل بوضوح إنها غير متاحة بدل اختلاقها.

            بيانات Pinky الحالية:
            $liveContext

            سؤال المستخدم:
            $question
        """.trimIndent()

        val body = JSONObject()
            .put("contents", JSONArray().put(
                JSONObject()
                    .put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            )).toString()

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
        val request = Request.Builder()
            .url(url)
            .post(body.toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            val responseBody = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException("Gemini HTTP ${response.code}: ${responseBody.take(500)}")
            val root = JSONObject(responseBody)
            val candidates = root.optJSONArray("candidates") ?: return@withContext null
            if (candidates.length() == 0) return@withContext null
            val parts = candidates.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: return@withContext null
            buildString {
                for (i in 0 until parts.length()) append(parts.optJSONObject(i)?.optString("text").orEmpty())
            }.ifBlank { null }
        }
    }

    private fun buildLiveContext(orders: List<Order>, products: List<Product>, customers: List<Customer>, analytics: AnalyticsData, currentUser: AdminUser?): String {
        val lowStock = products.filter { it.stock <= 10 }.take(30).joinToString("\n") { "- ${it.name}: المخزون ${it.stock}" }
        val topProducts = analytics.topSellingProducts.take(10).joinToString("\n") { "- ${it.productName}: ${it.unitsSold} قطعة / ${it.totalRevenue} جنيه" }
        val govStats = orders.groupingBy { it.governorate.ifBlank { "غير محدد" } }.eachCount()
            .entries.sortedByDescending { it.value }.take(10).joinToString("\n") { "- ${it.key}: ${it.value} طلب" }
        return buildString {
            appendLine("إجمالي المبيعات: ${analytics.totalSales} جنيه")
            appendLine("إجمالي الطلبات: ${analytics.totalOrders}")
            appendLine("متوسط الطلب: ${analytics.averageOrderValue} جنيه")
            if (currentUser?.canViewProfit == true) appendLine("إجمالي الربح المقدر: ${analytics.totalProfit ?: 0.0} جنيه")
            appendLine("عدد العملاء: ${customers.size}")
            appendLine("الطلبات الجديدة: ${orders.count { it.status == OrderStatus.NEW }}")
            appendLine("الطلبات الملغاة: ${orders.count { it.status == OrderStatus.CANCELLED }}")
            appendLine("\nأكثر المنتجات مبيعًا:\n${topProducts.ifBlank { "لا يوجد" }}")
            appendLine("\nمخزون منخفض:\n${lowStock.ifBlank { "لا يوجد" }}")
            appendLine("\nالمحافظات حسب عدد الطلبات:\n${govStats.ifBlank { "لا يوجد" }}")
        }
    }

    private fun localFallback(userQuery: String, orders: List<Order>, products: List<Product>, customers: List<Customer>, analytics: AnalyticsData, currentUser: AdminUser?): String {
        return when {
            userQuery.contains("مبيعات") || userQuery.contains("المبيعات") -> {
                val profitText = if (currentUser?.canViewProfit == true) "\n• صافي الأرباح المقدرة: ${Formatters.formatCurrencyEgp(analytics.totalProfit ?: 0.0)}" else ""
                "📊 تقرير المبيعات الحالية لمتجر بينكي:\n• إجمالي المبيعات: ${Formatters.formatCurrencyEgp(analytics.totalSales)}\n• عدد الطلبات: ${analytics.totalOrders}\n• متوسط قيمة الطلب: ${Formatters.formatCurrencyEgp(analytics.averageOrderValue)}$profitText"
            }
            userQuery.contains("أكثر المنتجات") || userQuery.contains("الأكثر مبيعاً") -> analytics.topSellingProducts.take(5)
                .mapIndexed { index, item -> "${index + 1}. ${item.productName} — ${item.unitsSold} قطعة (${Formatters.formatCurrencyEgp(item.totalRevenue)})" }
                .joinToString("\n").ifBlank { "لا توجد بيانات مبيعات كافية حاليًا." }
            userQuery.contains("مخزون") || userQuery.contains("إعادة تخزين") -> products.filter { it.stock <= 10 }
                .joinToString("\n") { "• ${it.name}: ${it.stock} قطعة" }.ifBlank { "جميع المنتجات الحالية فوق حد المخزون المنخفض." }
            userQuery.contains("الطلبات الجديدة") || userQuery.contains("جديدة") -> {
                val newOrders = orders.filter { it.status == OrderStatus.NEW }
                "لديك ${newOrders.size} طلبات جديدة بقيمة ${Formatters.formatCurrencyEgp(newOrders.sumOf { it.totalAmount })}."
            }
            userQuery.contains("المحافظات") || userQuery.contains("شحن") -> orders.groupingBy { it.governorate.ifBlank { "غير محدد" } }.eachCount()
                .entries.sortedByDescending { it.value }.take(5).joinToString("\n") { "• ${it.key}: ${it.value} طلب" }
                .ifBlank { "لا توجد طلبات مسجلة بالمحافظات حاليًا." }
            else -> "مساعد Pinky متصل ببيانات الداشبورد. لتفعيل الإجابات العامة المفتوحة، أضف GEMINI_API_KEY إلى ملف .env؛ أما أسئلة المبيعات والمخزون والطلبات الأساسية فأستطيع الإجابة عنها من البيانات الحالية."
        }
    }
}
