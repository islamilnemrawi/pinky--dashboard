package com.pinky.dashboard.data.remote

object SupabaseConfig {
    // Default Supabase configuration
    // Uses the public anon key for Row Level Security (RLS)
    // CRITICAL: NEVER include the service_role key in the Android APK
    const val DEFAULT_SUPABASE_URL = "https://dmttevcncsxzbamazmmq.supabase.co"
    // Supabase Publishable Key from the existing Elory storefront. This is public by design;
    // all data access is still restricted by Supabase Auth and RLS policies.
    const val DEFAULT_ANON_KEY = "sb_publishable_UxXOA92gcX3CHzbU7h3udQ_3khfMMzH"

    // Tables supporting backward compatibility with existing Elora schema
    const val TABLE_ORDERS = "orders"
    const val TABLE_ORDERS_LEGACY = "elora_orders"
    const val TABLE_ORDER_ITEMS = "order_items"
    const val TABLE_ORDER_ITEMS_LEGACY = "elora_order_items"
    const val TABLE_PRODUCTS = "products"
    const val TABLE_PRODUCTS_LEGACY = "elora_products"
    const val TABLE_CATEGORIES = "categories"
    const val TABLE_OFFERS = "offers"
    const val TABLE_CUSTOMERS = "customers"
    const val TABLE_SHIPPING = "shipping_rates"
    const val TABLE_ADMIN_PROFILES = "staff_profiles"
    const val PAGE_SIZE = 1000

    // Cloud Storage Bucket for product images
    const val BUCKET_PRODUCT_IMAGES = "pinky-products"
    const val BUCKET_BANNERS = "pinky-banners"
}
