package com.pinky.dashboard

import com.pinky.dashboard.core.util.toEpochMillisOrNull
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SupabaseTimestampTest {
    @Test fun parsesIsoUtcTimestamp() {
        assertEquals(1793953800000L, "2026-11-06T08:30:00Z".toEpochMillisOrNull())
    }

    @Test fun parsesEpochSecondsAndMilliseconds() {
        assertEquals(1793953800000L, "1793953800".toEpochMillisOrNull())
        assertEquals(1793953800000L, "1793953800000".toEpochMillisOrNull())
    }

    @Test fun rejectsMalformedTimestamp() {
        assertNull("not-a-date".toEpochMillisOrNull())
    }
}
