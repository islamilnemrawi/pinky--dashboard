package com.pinky.dashboard.core.util

import java.time.Instant
import java.time.LocalDate
import java.time.OffsetDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeParseException

/** Parses PostgREST timestamptz strings and legacy epoch values without silently replacing valid dates. */
fun String?.toEpochMillisOrNull(): Long? {
    val value = this?.trim()?.takeIf { it.isNotEmpty() } ?: return null
    value.toLongOrNull()?.let { raw ->
        return if (raw in -99_999_999_999L..99_999_999_999L) raw * 1000L else raw
    }
    try { return Instant.parse(value).toEpochMilli() } catch (_: DateTimeParseException) { }
    try { return OffsetDateTime.parse(value).toInstant().toEpochMilli() } catch (_: DateTimeParseException) { }
    try { return LocalDate.parse(value).atStartOfDay().toInstant(ZoneOffset.UTC).toEpochMilli() } catch (_: DateTimeParseException) { }
    return null
}

fun Long.toSupabaseIsoTimestamp(): String = Instant.ofEpochMilli(this).toString()
