package com.pinky.dashboard.data.repository

import com.pinky.dashboard.BuildConfig

import com.pinky.dashboard.data.local.PinkyDatabase
import com.pinky.dashboard.data.local.entity.*
import com.pinky.dashboard.data.remote.*
import com.pinky.dashboard.domain.model.*
import com.pinky.dashboard.domain.repository.*
import com.pinky.dashboard.core.util.toEpochMillisOrNull
import com.pinky.dashboard.core.util.toSupabaseIsoTimestamp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun isNetworkException(e: Throwable): Boolean {
    val msg = e.message ?: ""
    return e is java.net.UnknownHostException ||
           e is java.net.ConnectException ||
           e is java.net.SocketTimeoutException ||
           e is java.io.InterruptedIOException ||
           msg.contains("Unable to resolve host", ignoreCase = true) ||
           msg.contains("No address associated with hostname", ignoreCase = true) ||
           msg.contains("Failed to connect", ignoreCase = true)
}

private fun isSupabasePermissionError(code: Int, payload: String?): Boolean {
    if (code == 403 || code == 401) return true
    val lower = payload?.lowercase() ?: ""
    return lower.contains("42501") ||
           lower.contains("permission denied") ||
           lower.contains("privileges") ||
           lower.contains("row-level security") ||
           lower.contains("rls")
}

class OrderRepositoryImpl(
    private val database: PinkyDatabase
) : OrderRepository {
    private val orderDao = database.orderDao()

    override fun getOrdersFlow(): Flow<List<Order>> {
        return orderDao.getAllOrdersFlow().map { entities ->
            entities.map { entity ->
                val items = orderDao.getOrderItems(entity.id).map { itemEntity ->
                    OrderItem(
                        id = itemEntity.id,
                        productId = itemEntity.productId,
                        productName = itemEntity.productName,
                        variantName = itemEntity.variantName,
                        color = itemEntity.color,
                        size = itemEntity.size,
                        quantity = itemEntity.quantity,
                        unitPrice = itemEntity.unitPrice,
                        lineTotal = itemEntity.lineTotal,
                        imageUrl = itemEntity.imageUrl
                    )
                }
                Order(
                    id = entity.id,
                    orderNumber = entity.orderNumber,
                    customerName = entity.customerName,
                    customerPhone = entity.customerPhone,
                    customerAddress = entity.customerAddress,
                    governorate = entity.governorate,
                    shippingCenter = entity.shippingCenter,
                    items = items,
                    subtotalAmount = entity.subtotalAmount,
                    shippingFee = entity.shippingFee,
                    discountAmount = entity.discountAmount,
                    totalAmount = entity.totalAmount,
                    paymentMethod = PaymentMethod.fromString(entity.paymentMethod),
                    paymentStatus = PaymentStatus.valueOf(entity.paymentStatus),
                    status = OrderStatus.fromString(entity.status),
                    createdAt = entity.createdAt,
                    notes = entity.notes,
                    prime = entity.prime,
                    profit = entity.profit,
                    couponCode = entity.couponCode,
                    couponDiscount = entity.couponDiscount,
                    couponFreeShipping = entity.couponFreeShipping
                )
            }
        }.flowOn(Dispatchers.IO)
    }

    override suspend fun getOrderById(orderId: String): Order? = withContext(Dispatchers.IO) {
        val entity = orderDao.getOrderById(orderId) ?: return@withContext null
        val items = orderDao.getOrderItems(entity.id).map { itemEntity ->
            OrderItem(
                id = itemEntity.id,
                productId = itemEntity.productId,
                productName = itemEntity.productName,
                variantName = itemEntity.variantName,
                color = itemEntity.color,
                size = itemEntity.size,
                quantity = itemEntity.quantity,
                unitPrice = itemEntity.unitPrice,
                lineTotal = itemEntity.lineTotal,
                imageUrl = itemEntity.imageUrl
            )
        }
        Order(
            id = entity.id,
            orderNumber = entity.orderNumber,
            customerName = entity.customerName,
            customerPhone = entity.customerPhone,
            customerAddress = entity.customerAddress,
            governorate = entity.governorate,
            shippingCenter = entity.shippingCenter,
            items = items,
            subtotalAmount = entity.subtotalAmount,
            shippingFee = entity.shippingFee,
            discountAmount = entity.discountAmount,
            totalAmount = entity.totalAmount,
            paymentMethod = PaymentMethod.fromString(entity.paymentMethod),
            paymentStatus = PaymentStatus.valueOf(entity.paymentStatus),
            status = OrderStatus.fromString(entity.status),
            createdAt = entity.createdAt,
            notes = entity.notes,
            prime = entity.prime,
            profit = entity.profit,
            couponCode = entity.couponCode,
            couponDiscount = entity.couponDiscount,
            couponFreeShipping = entity.couponFreeShipping
        )
    }

    override suspend fun updateOrderStatus(
        orderId: String,
        newStatus: OrderStatus,
        note: String?
    ): Result<Order> = withContext(Dispatchers.IO) {
        try {
            // 1. Update in Supabase
            val response = SupabaseClient.service.updateOrderStatus(
                "eq.$orderId",
                mapOf("status" to newStatus.arabicLabel)
            )
            if (!response.isSuccessful) {
                val errorMsg = response.errorBody()?.string() ?: response.message()
                return@withContext Result.failure(Exception("Supabase updateOrderStatus failed: $errorMsg"))
            }

            // 2. Update local Cache
            orderDao.updateOrderStatus(orderId, newStatus.arabicLabel)
            val updated = getOrderById(orderId) ?: throw IllegalStateException("Order not found")
            Result.success(updated)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun syncOrders(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val response = SupabaseClient.service.getOrders()
            if (response.isSuccessful) {
                val orders = response.body() ?: emptyList()
                val orderEntities = orders.map { dto ->
                    OrderEntity(
                        id = dto.id,
                        orderNumber = dto.orderNumber,
                        customerName = dto.customerName,
                        customerPhone = dto.phone,
                        customerAddress = dto.address ?: "",
                        governorate = dto.governorate ?: "",
                        shippingCenter = dto.center ?: "",
                        subtotalAmount = dto.subtotal ?: 0.0,
                        shippingFee = dto.shippingCost ?: 0.0,
                        discountAmount = dto.discountAmount ?: 0.0,
                        totalAmount = dto.total ?: 0.0,
                        paymentMethod = dto.paymentMethod ?: "",
                        paymentStatus = if (dto.status == "تم التسليم" || dto.status == "DELIVERED") "PAID" else "PENDING",
                        status = dto.status ?: "NEW",
                        createdAt = dto.createdAt.toEpochMillisOrNull() ?: 0L,
                        notes = dto.notes ?: "",
                        isSynced = true,
                        prime = dto.prime ?: false,
                        profit = dto.profit ?: 0.0,
                        couponCode = dto.couponCode ?: "",
                        couponDiscount = dto.couponDiscount ?: 0.0,
                        couponFreeShipping = dto.couponFreeShipping ?: false
                    )
                }
                orderDao.insertOrders(orderEntities)

                val itemEntities = orders.flatMap { dto ->
                    dto.items?.map { item ->
                        OrderItemEntity(
                            id = item.id ?: java.util.UUID.randomUUID().toString(),
                            orderId = dto.id,
                            productId = item.productId ?: "",
                            productName = item.productName ?: "",
                            variantName = item.variantName ?: "",
                            color = item.color ?: "",
                            size = item.size ?: "",
                            quantity = item.quantity ?: 1,
                            unitPrice = item.unitPrice ?: 0.0,
                            lineTotal = item.lineTotal ?: 0.0,
                            imageUrl = item.imageUrl ?: ""
                        )
                    } ?: emptyList()
                }
                if (itemEntities.isNotEmpty()) {
                    orderDao.insertOrderItems(itemEntities)
                }
                android.util.Log.d("SupabaseSync", "Table: orders | Operation: syncOrders | Status: Success | Count: ${orders.size}")
                Result.success(Unit)
            } else {
                val errorBodyStr = response.errorBody()?.string() ?: ""
                val errMsg = "Table: orders | Operation: syncOrders | Error: HTTP ${response.code()} ${response.message()} | Payload: $errorBodyStr"
                if (isSupabasePermissionError(response.code(), errorBodyStr)) {
                    android.util.Log.w("SupabaseSync", "Table: orders | Operation: syncOrders | Status: Restricted (HTTP ${response.code()} / RLS). Using local cached data.")
                    Result.success(Unit)
                } else {
                    android.util.Log.e("SupabaseError", errMsg)
                    Result.failure(Exception(errMsg))
                }
            }
        } catch (e: Exception) {
            if (isNetworkException(e)) {
                android.util.Log.w("SupabaseSync", "syncOrders offline: ${e.message}")
            } else {
                android.util.Log.e("SupabaseError", "Table: orders | Operation: syncOrders | Exception: ${e.message}", e)
            }
            Result.failure(e)
        }
    }

    override suspend fun addOrder(order: Order): Result<Order> = withContext(Dispatchers.IO) {
        try {
            // 1. Save to Supabase (Natively including items in the JSONB column!)
            val orderItemsDto = order.items.map { item ->
                SupabaseOrderItemDto(
                    id = item.id,
                    orderId = order.id,
                    productId = item.productId,
                    productName = item.productName,
                    variantName = item.variantName,
                    color = item.color,
                    size = item.size,
                    quantity = item.quantity,
                    unitPrice = item.unitPrice,
                    lineTotal = item.lineTotal,
                    imageUrl = item.imageUrl
                )
            }

            val dto = SupabaseOrderDto(
                id = order.id,
                orderNumber = order.orderNumber,
                customerName = order.customerName,
                phone = order.customerPhone,
                address = order.customerAddress,
                governorate = order.governorate,
                center = order.shippingCenter,
                subtotal = order.subtotalAmount,
                shippingCost = order.shippingFee,
                discountAmount = order.discountAmount,
                total = order.totalAmount,
                paymentMethod = order.paymentMethod.arabicLabel,
                status = order.status.arabicLabel,
                createdAt = order.createdAt.toSupabaseIsoTimestamp(),
                notes = order.notes,
                items = orderItemsDto
            )

            val isPlaceholderKey = SupabaseClient.supabaseAnonKey.contains("placeholder")
            if (!isPlaceholderKey) {
                val orderResponse = SupabaseClient.service.upsertOrder(dto)
                if (!orderResponse.isSuccessful) {
                    val errorMsg = orderResponse.errorBody()?.string() ?: orderResponse.message()
                    return@withContext Result.failure(Exception("Supabase addOrder failed: $errorMsg"))
                }
            }

            // 2. Save to local Cache
            val entity = OrderEntity(
                id = order.id,
                orderNumber = order.orderNumber,
                customerName = order.customerName,
                customerPhone = order.customerPhone,
                customerAddress = order.customerAddress,
                governorate = order.governorate,
                shippingCenter = order.shippingCenter,
                subtotalAmount = order.subtotalAmount,
                shippingFee = order.shippingFee,
                discountAmount = order.discountAmount,
                totalAmount = order.totalAmount,
                paymentMethod = order.paymentMethod.arabicLabel,
                paymentStatus = order.paymentStatus.name,
                status = order.status.arabicLabel,
                createdAt = order.createdAt,
                notes = order.notes,
                isSynced = true
            )
            orderDao.insertOrder(entity)

            val itemEntities = order.items.map { item ->
                OrderItemEntity(
                    id = item.id,
                    orderId = order.id,
                    productId = item.productId,
                    productName = item.productName,
                    variantName = item.variantName,
                    color = item.color,
                    size = item.size,
                    quantity = item.quantity,
                    unitPrice = item.unitPrice,
                    lineTotal = item.lineTotal,
                    imageUrl = item.imageUrl
                )
            }
            orderDao.insertOrderItems(itemEntities)

            // Update or insert customer locally & remotely
            val existingCustomer = database.customerDao().getCustomerByPhone(order.customerPhone)
            val customer = CustomerEntity(
                id = existingCustomer?.id ?: "cust_${System.currentTimeMillis()}",
                name = order.customerName,
                phone = order.customerPhone,
                email = existingCustomer?.email,
                address = order.customerAddress,
                governorate = order.governorate,
                totalOrders = (existingCustomer?.totalOrders ?: 0) + 1,
                totalSpend = (existingCustomer?.totalSpend ?: 0.0) + order.totalAmount,
                firstOrderDate = existingCustomer?.firstOrderDate ?: order.createdAt,
                lastOrderDate = order.createdAt
            )
            database.customerDao().insertCustomer(customer)

            try {
                if (!isPlaceholderKey) {
                    val customerDto = SupabaseCustomerDto(
                        id = customer.id,
                        name = customer.name,
                        phone = customer.phone,
                        email = customer.email,
                        address = customer.address,
                        governorate = customer.governorate,
                        totalOrders = customer.totalOrders,
                        totalSpend = customer.totalSpend,
                        firstOrderDate = customer.firstOrderDate.toString(),
                        lastOrderDate = customer.lastOrderDate.toString()
                    )
                    SupabaseClient.service.upsertCustomer(customerDto)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            Result.success(order)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

class ProductRepositoryImpl(
    private val database: PinkyDatabase
) : ProductRepository {
    private val productDao = database.productDao()

    override fun getProductsFlow(): Flow<List<Product>> {
        return productDao.getAllProductsFlow().map { entities ->
            entities.map { it.toDomain() }
        }.flowOn(Dispatchers.IO)
    }

    override suspend fun getProductById(productId: String): Product? = withContext(Dispatchers.IO) {
        productDao.getProductById(productId)?.toDomain()
    }

    override suspend fun saveProduct(product: Product): Result<Product> = withContext(Dispatchers.IO) {
        try {
            // 1. Save to Supabase (using products table via SupabaseProductAdminDto)
            val dto = SupabaseProductAdminDto(
                id = product.id,
                name = product.name,
                description = product.description,
                image = product.imageUrl,
                category = product.categoryName,
                price = product.price,
                oldPrice = product.oldPrice,
                wholesalePrice = product.wholesalePrice,
                code = product.internalCode,
                stock = product.stock,
                discount = product.discountPercent,
                featured = product.isFeatured,
                active = product.isActive,
                createdAt = product.createdAt.toSupabaseIsoTimestamp(),
                colors = product.colors,
                sizes = product.sizes,
                gallery = product.gallery
            )
            val response = SupabaseClient.service.upsertAdminProduct(dto)
            if (!response.isSuccessful) {
                val errorMsg = response.errorBody()?.string() ?: response.message()
                return@withContext Result.failure(Exception("Supabase saveProduct failed: $errorMsg"))
            }

            // 2. Save to local Cache
            val entity = ProductEntity(
                id = product.id,
                name = product.name,
                description = product.description,
                imageUrl = product.imageUrl,
                galleryJson = product.gallery.joinToString(","),
                categoryId = product.categoryId,
                categoryName = product.categoryName,
                price = product.price,
                oldPrice = product.oldPrice,
                discountPercent = product.discountPercent,
                wholesalePrice = product.wholesalePrice,
                internalCode = product.internalCode,
                stock = product.stock,
                colorsJson = product.colors.joinToString(","),
                sizesJson = product.sizes.joinToString(","),
                isActive = product.isActive,
                isFeatured = product.isFeatured,
                createdAt = product.createdAt
            )
            productDao.insertProduct(entity)
            Result.success(product)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteProduct(productId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            // 1. Delete from Supabase products table
            val response = SupabaseClient.service.deleteAdminProduct("eq.$productId")
            if (!response.isSuccessful) {
                val errorMsg = response.errorBody()?.string() ?: response.message()
                return@withContext Result.failure(Exception("Supabase deleteProduct failed: $errorMsg"))
            }

            // 2. Delete from local Cache
            productDao.deleteProduct(productId)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun toggleProductActive(productId: String, isActive: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            // 1. Patch in Supabase products table
            val response = SupabaseClient.service.patchAdminProduct("eq.$productId", mapOf("active" to isActive))
            if (!response.isSuccessful) {
                val errorMsg = response.errorBody()?.string() ?: response.message()
                return@withContext Result.failure(Exception("Supabase toggleProductActive failed: $errorMsg"))
            }

            // 2. Update local Cache
            productDao.updateActiveStatus(productId, isActive)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun syncProducts(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            if (!SupabaseClient.hasValidConfiguration) {
                return@withContext Result.failure(Exception("إعدادات اتصال Supabase غير مكتملة."))
            }

            if (!SupabaseClient.isAuthenticated || SupabaseClient.accessToken.isNullOrBlank()) {
                return@withContext Result.failure(Exception("سجّل الدخول بحساب موظف نشط قبل مزامنة بيانات المنتجات."))
            }

            val allAdminRows = mutableListOf<SupabaseProductAdminDto>()
            var offset = 0
            while (true) {
                val range = "$offset-${offset + SupabaseConfig.PAGE_SIZE - 1}"
                val response = SupabaseClient.service.getAdminProducts("*", "id.asc", range, "items")
                if (!response.isSuccessful) {
                    val error = response.errorBody()?.string().orEmpty()
                    val message = "تعذر جلب المنتجات من Supabase (HTTP ${response.code()})."
                    if (isSupabasePermissionError(response.code(), error)) {
                        android.util.Log.w("ElorySync", "$message تم الاحتفاظ بالنسخة المحلية دون استبدالها.")
                    }
                    return@withContext Result.failure(Exception(message))
                }
                val page = response.body().orEmpty()
                allAdminRows.addAll(page)
                if (page.size < SupabaseConfig.PAGE_SIZE) break
                offset += page.size
            }

            val entities = allAdminRows.map { dto ->
                    ProductEntity(
                        id = dto.id,
                        name = dto.name,
                        description = dto.description ?: "",
                        imageUrl = dto.image ?: "",
                        galleryJson = dto.gallery?.joinToString(",") ?: "",
                        categoryId = "",
                        categoryName = dto.category ?: "",
                        price = dto.price,
                        oldPrice = dto.oldPrice,
                        discountPercent = dto.discount,
                        wholesalePrice = dto.wholesalePrice,
                        internalCode = dto.code,
                        stock = dto.stock ?: 0,
                        colorsJson = dto.colors?.joinToString(",") ?: "",
                        sizesJson = dto.sizes?.joinToString(",") ?: "",
                        isActive = dto.active ?: true,
                        isFeatured = dto.featured ?: false,
                        createdAt = dto.createdAt.toEpochMillisOrNull() ?: 0L
                    )
            }

            // Replace the cache only after every authenticated admin page has arrived successfully.
            // This removes stale/deleted rows without downgrading richer admin fields to public-view data.
            productDao.replaceProducts(entities)
            android.util.Log.i("ElorySync", "Products synchronized: ${entities.size} rows")
            Result.success(Unit)
        } catch (e: Exception) {
            if (isNetworkException(e)) {
                android.util.Log.w("ElorySync", "Product sync offline; cached data preserved.")
            } else {
                android.util.Log.e("ElorySync", "Product sync failed (${e.javaClass.simpleName}).", e)
            }
            Result.failure(e)
        }
    }

    private fun ProductEntity.toDomain(): Product {
        return Product(
            id = id,
            name = name,
            description = description,
            imageUrl = imageUrl,
            gallery = if (galleryJson.isBlank()) emptyList() else galleryJson.split(",").filter { it.isNotBlank() },
            categoryId = categoryId,
            categoryName = categoryName,
            price = price,
            oldPrice = oldPrice,
            discountPercent = discountPercent,
            wholesalePrice = wholesalePrice,
            internalCode = internalCode,
            stock = stock,
            colors = if (colorsJson.isBlank()) emptyList() else colorsJson.split(",").filter { it.isNotBlank() },
            sizes = if (sizesJson.isBlank()) emptyList() else sizesJson.split(",").filter { it.isNotBlank() },
            isActive = isActive,
            isFeatured = isFeatured,
            createdAt = createdAt
        )
    }
}

class CategoryRepositoryImpl(
    private val database: PinkyDatabase
) : CategoryRepository {
    private val categoryDao = database.categoryDao()

    override fun getCategoriesFlow(): Flow<List<Category>> {
        return combine(
            categoryDao.getAllCategoriesFlow(),
            database.productDao().getAllProductsFlow()
        ) { categories, products ->
            categories.map { cat ->
                val count = products.count { it.categoryId == cat.id || it.categoryName == cat.name }
                Category(
                    id = cat.id,
                    name = cat.name,
                    imageUrl = cat.imageUrl,
                    sortOrder = cat.sortOrder,
                    isActive = cat.isActive,
                    productsCount = count
                )
            }
        }.flowOn(Dispatchers.IO)
    }

    override suspend fun saveCategory(category: Category): Result<Category> = withContext(Dispatchers.IO) {
        try {
            // 1. Save to Supabase
            val dto = SupabaseCategoryDto(
                id = category.id,
                name = category.name,
                slug = category.slug,
                image = category.imageUrl,
                sortOrder = category.sortOrder,
                active = category.isActive
            )
            val response = SupabaseClient.service.upsertCategory(dto)
            if (!response.isSuccessful) {
                val errorMsg = response.errorBody()?.string() ?: response.message()
                return@withContext Result.failure(Exception("Supabase saveCategory failed: $errorMsg"))
            }

            // 2. Read-after-write verification from the same Supabase source of truth.
            val verify = SupabaseClient.service.getCategories()
            if (!verify.isSuccessful) {
                val errorMsg = verify.errorBody()?.string() ?: verify.message()
                return@withContext Result.failure(Exception("Supabase category verification failed: $errorMsg"))
            }
            val persisted = verify.body()?.firstOrNull { it.id == category.id }
            if (persisted == null || persisted.name != category.name) {
                return@withContext Result.failure(Exception("تم الحفظ ظاهريًا لكن لم يتم العثور على القسم بعد الحفظ في Supabase."))
            }

            // 3. Save to local Cache
            val entity = CategoryEntity(
                id = category.id,
                name = category.name,
                imageUrl = category.imageUrl,
                sortOrder = category.sortOrder,
                isActive = category.isActive,
                productsCount = category.productsCount
            )
            categoryDao.insertCategory(entity)
            Result.success(category)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteCategory(categoryId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            // 1. Delete from Supabase
            val response = SupabaseClient.service.deleteCategory("eq.$categoryId")
            if (!response.isSuccessful) {
                val errorMsg = response.errorBody()?.string() ?: response.message()
                return@withContext Result.failure(Exception("Supabase deleteCategory failed: $errorMsg"))
            }

            // 2. Delete from local Cache
            categoryDao.deleteCategory(categoryId)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun clearLocalCategories() = withContext(Dispatchers.IO) {
        categoryDao.deleteAllCategories()
    }

    private fun extractFromJson(json: String, key: String): String {
        val pattern = "\"$key\"\\s*:\\s*\"([^\"]*)\"".toRegex()
        val match = pattern.find(json)
        return match?.groupValues?.get(1) ?: "N/A"
    }

    override suspend fun syncCategories(): Result<Unit> = withContext(Dispatchers.IO) {
        val hasSession = SupabaseClient.userToken != null
        android.util.Log.i("SupabaseDiagnostic", "CATEGORIES SYNC START | Has Auth Session: $hasSession")
        try {
            val response = SupabaseClient.service.getCategories()
            android.util.Log.i("SupabaseDiagnostic", "CATEGORIES HTTP STATUS: ${response.code()}")
            
            if (response.isSuccessful) {
                val dtoList = response.body() ?: emptyList()
                android.util.Log.i("SupabaseDiagnostic", "CATEGORIES ROW COUNT: ${dtoList.size}")
                android.util.Log.i("SupabaseDiagnostic", "CATEGORIES NAMES: ${dtoList.joinToString { it.name }}")
                val entities = dtoList.map { dto ->
                    CategoryEntity(
                        id = dto.id,
                        name = dto.name,
                        imageUrl = dto.image ?: "",
                        sortOrder = dto.sortOrder ?: 0,
                        isActive = dto.active ?: true,
                        productsCount = 0
                    )
                }
                categoryDao.deleteAllCategories()
                categoryDao.insertCategories(entities)
                android.util.Log.d("SupabaseSync", "Table: categories | Operation: syncCategories | Status: Success | Count: ${entities.size}")
                Result.success(Unit)
            } else {
                val errorBodyStr = response.errorBody()?.string() ?: ""
                android.util.Log.i("SupabaseDiagnostic", "Supabase categories error: ${response.code()} | Payload: $errorBodyStr")
                val errCode = extractFromJson(errorBodyStr, "code")
                val errMsg = extractFromJson(errorBodyStr, "message")
                android.util.Log.w("SupabaseDiagnostic", "CATEGORIES SUPABASE ERROR CODE: $errCode")
                android.util.Log.w("SupabaseDiagnostic", "CATEGORIES SUPABASE ERROR MESSAGE: $errMsg")
                
                val fullErrMsg = "Table: categories | Operation: syncCategories | Error: HTTP ${response.code()} ${response.message()} | Payload: $errorBodyStr"
                android.util.Log.w("SupabaseError", fullErrMsg)
                Result.failure(Exception("خطأ في جلب الأقسام من الخادم (رمز الخطأ: $errCode): $errMsg"))
            }
        } catch (e: Exception) {
            android.util.Log.w("SupabaseDiagnostic", "CATEGORIES SUPABASE ERROR CODE: EXCEPTION")
            android.util.Log.w("SupabaseDiagnostic", "CATEGORIES SUPABASE ERROR MESSAGE: ${e.message ?: "Unknown Exception"}")
            if (isNetworkException(e)) {
                android.util.Log.w("SupabaseSync", "syncCategories offline: ${e.message}")
            } else {
                android.util.Log.w("SupabaseError", "Table: categories | Operation: syncCategories | Exception: ${e.message}", e)
            }
            Result.failure(e)
        }
    }
}

class OfferRepositoryImpl(
    private val database: PinkyDatabase
) : OfferRepository {
    private val offerDao = database.offerDao()

    override fun getOffersFlow(): Flow<List<Offer>> {
        return offerDao.getAllOffersFlow().map { entities ->
            entities.map {
                Offer(
                    id = it.id,
                    title = it.title,
                    description = it.description,
                    discountText = it.discountText,
                    imageUrl = it.imageUrl,
                    buttonText = it.buttonText,
                    targetCategoryId = it.targetCategoryId,
                    targetCategoryName = it.targetCategoryName,
                    sortOrder = it.sortOrder,
                    isActive = it.isActive,
                    isBanner = it.id.startsWith("ban_"),
                    startDate = it.startDate,
                    endDate = it.endDate
                )
            }
        }.flowOn(Dispatchers.IO)
    }

    override suspend fun saveOffer(offer: Offer): Result<Offer> = withContext(Dispatchers.IO) {
        try {
            if (!SupabaseClient.hasValidConfiguration || !SupabaseClient.isAuthenticated) {
                return@withContext Result.failure(Exception("يجب تسجيل الدخول بحساب مخوّل لحفظ العروض والبنرات."))
            }
            val isBanner = offer.isBanner || offer.id.startsWith("ban_")
            val response = if (isBanner) {
                SupabaseClient.service.upsertBanner(
                    SupabaseBannerDto(
                        id = offer.id,
                        title = offer.title,
                        subtitle = offer.description,
                        image = offer.imageUrl,
                        buttonText = offer.buttonText,
                        buttonAction = offer.targetCategoryId ?: offer.targetCategoryName,
                        sortOrder = offer.sortOrder,
                        active = offer.isActive
                    )
                )
            } else {
                SupabaseClient.service.upsertOffer(
                    SupabaseOfferDto(
                        id = offer.id,
                        title = offer.title,
                        description = offer.description,
                        discount = offer.discountText,
                        image = offer.imageUrl,
                        active = offer.isActive,
                        startsAt = offer.startDate.toSupabaseIsoTimestamp(),
                        endsAt = offer.endDate.toSupabaseIsoTimestamp(),
                        buttonText = offer.buttonText,
                        targetCategory = offer.targetCategoryId ?: offer.targetCategoryName,
                        sortOrder = offer.sortOrder,
                        isActive = offer.isActive
                    )
                )
            }
            if (!response.isSuccessful) {
                val httpError = response.code()
                return@withContext Result.failure(Exception("فشل حفظ ${if (isBanner) "البانر" else "العرض"} على Supabase (HTTP $httpError)."))
            }

            val entity = OfferEntity(
                id = offer.id,
                title = offer.title,
                description = offer.description,
                discountText = offer.discountText,
                imageUrl = offer.imageUrl,
                buttonText = offer.buttonText,
                targetCategoryId = offer.targetCategoryId,
                targetCategoryName = offer.targetCategoryName,
                sortOrder = offer.sortOrder,
                isActive = offer.isActive,
                startDate = offer.startDate,
                endDate = offer.endDate
            )
            offerDao.insertOffer(entity)
            Result.success(offer)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteOffer(offerId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            if (!SupabaseClient.hasValidConfiguration || !SupabaseClient.isAuthenticated) {
                return@withContext Result.failure(Exception("يجب تسجيل الدخول بحساب مخوّل لحذف العروض والبنرات."))
            }
            val isBanner = offerId.startsWith("ban_")
            val response = if (isBanner) {
                SupabaseClient.service.deleteBanner("eq.$offerId")
            } else {
                SupabaseClient.service.deleteOffer("eq.$offerId")
            }
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("فشل حذف العنصر من Supabase (HTTP ${response.code()})."))
            }
            offerDao.deleteOffer(offerId)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun syncOffers(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            if (!SupabaseClient.hasValidConfiguration) {
                return@withContext Result.failure(Exception("إعدادات اتصال Supabase غير مكتملة."))
            }
            val offersResp = SupabaseClient.service.getOffers()
            if (!offersResp.isSuccessful) {
                return@withContext Result.failure(Exception("تعذر تحميل العروض من Supabase (HTTP ${offersResp.code()})."))
            }
            val bannersResp = SupabaseClient.service.getBanners()
            if (!bannersResp.isSuccessful) {
                return@withContext Result.failure(Exception("تعذر تحميل البنرات من Supabase (HTTP ${bannersResp.code()})."))
            }

            val now = System.currentTimeMillis()
            val entities = mutableListOf<OfferEntity>()
            offersResp.body().orEmpty().forEach { dto ->
                entities.add(
                    OfferEntity(
                        id = dto.id,
                        title = dto.title,
                        description = dto.description ?: "",
                        discountText = dto.discount ?: "",
                        imageUrl = dto.image ?: "",
                        buttonText = dto.buttonText ?: "تسوقي الآن",
                        targetCategoryId = dto.targetCategory,
                        targetCategoryName = dto.targetCategory ?: "",
                        sortOrder = dto.sortOrder ?: 0,
                        isActive = dto.active ?: dto.isActive ?: true,
                        startDate = dto.startsAt.toEpochMillisOrNull() ?: now,
                        endDate = dto.endsAt.toEpochMillisOrNull() ?: (now + 30L * 24 * 60 * 60 * 1000)
                    )
                )
            }
            bannersResp.body().orEmpty().forEach { dto ->
                val finalId = if (dto.id.startsWith("ban_")) dto.id else "ban_${dto.id}"
                entities.add(
                    OfferEntity(
                        id = finalId,
                        title = dto.title,
                        description = dto.subtitle ?: "",
                        discountText = "",
                        imageUrl = dto.image ?: "",
                        buttonText = dto.buttonText ?: "تسوقي الآن",
                        targetCategoryId = dto.buttonAction,
                        targetCategoryName = dto.buttonAction ?: "",
                        sortOrder = dto.sortOrder ?: 0,
                        isActive = dto.active ?: true,
                        startDate = now,
                        endDate = now + 365L * 24 * 60 * 60 * 1000
                    )
                )
            }
            offerDao.replaceOffers(entities)
            Result.success(Unit)
        } catch (e: Exception) {
            if (isNetworkException(e)) android.util.Log.w("ElorySync", "Offer sync offline; cached data preserved.")
            else android.util.Log.e("ElorySync", "Offer sync failed (${e.javaClass.simpleName}).", e)
            Result.failure(e)
        }
    }

}

class ShippingRepositoryImpl(
    private val database: PinkyDatabase
) : ShippingRepository {
    private val shippingDao = database.shippingDao()

    override suspend fun clearLocalShipping() = withContext(Dispatchers.IO) {
        shippingDao.deleteAllGovernorates()
        shippingDao.deleteAllCenters()
    }

    override fun getGovernoratesFlow(): Flow<List<ShippingGovernorate>> {
        return shippingDao.getAllGovernoratesFlow().map { entities ->
            entities.map { ShippingGovernorate(it.id, it.name, it.deliveryPrice, it.estimatedDays, it.isActive) }
        }.flowOn(Dispatchers.IO)
    }

    override fun getShippingCentersFlow(): Flow<List<ShippingCenter>> {
        return shippingDao.getAllCentersFlow().map { entities ->
            entities.map { ShippingCenter(it.id, it.governorateId, it.name, it.deliveryPrice, it.contactNumber, it.isActive) }
        }.flowOn(Dispatchers.IO)
    }

    override suspend fun saveGovernorate(gov: ShippingGovernorate): Result<ShippingGovernorate> = withContext(Dispatchers.IO) {
        try {
            if (!SupabaseClient.hasValidConfiguration || !SupabaseClient.isAuthenticated) {
                return@withContext Result.failure(Exception("يجب تسجيل الدخول بحساب مخوّل لإدارة الشحن."))
            }
            val response = SupabaseClient.service.upsertGovernorate(
                SupabaseGovernorateDto(
                    governorate = gov.name,
                    price = gov.deliveryPrice,
                    centersEnabled = true,
                    active = gov.isActive
                )
            )
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("فشل حفظ المحافظة على Supabase (HTTP ${response.code()})."))
            }
            shippingDao.insertGovernorate(
                ShippingGovernorateEntity(gov.id, gov.name, gov.deliveryPrice, gov.estimatedDays, gov.isActive)
            )
            Result.success(gov)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun saveShippingCenter(center: ShippingCenter): Result<ShippingCenter> = withContext(Dispatchers.IO) {
        try {
            if (!SupabaseClient.hasValidConfiguration || !SupabaseClient.isAuthenticated) {
                return@withContext Result.failure(Exception("يجب تسجيل الدخول بحساب مخوّل لإدارة الشحن."))
            }
            val response = SupabaseClient.service.upsertShippingCenter(
                SupabaseShippingCenterDto(
                    id = center.id,
                    governorate = center.governorateId,
                    center = center.name,
                    price = center.deliveryPrice,
                    active = center.isActive
                )
            )
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("فشل حفظ مركز الشحن على Supabase (HTTP ${response.code()})."))
            }
            shippingDao.insertCenter(
                ShippingCenterEntity(center.id, center.governorateId, center.name, center.deliveryPrice, center.contactNumber, center.isActive)
            )
            Result.success(center)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteShippingCenter(centerId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            if (!SupabaseClient.hasValidConfiguration || !SupabaseClient.isAuthenticated) {
                return@withContext Result.failure(Exception("يجب تسجيل الدخول بحساب مخوّل لإدارة الشحن."))
            }
            val response = SupabaseClient.service.deleteShippingCenter("eq.$centerId")
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("فشل حذف مركز الشحن من Supabase (HTTP ${response.code()})."))
            }
            shippingDao.deleteCenter(centerId)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun syncShipping(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            if (!SupabaseClient.hasValidConfiguration) {
                return@withContext Result.failure(Exception("إعدادات اتصال Supabase غير مكتملة."))
            }
            val govResponse = SupabaseClient.service.getGovernorates()
            if (!govResponse.isSuccessful) {
                return@withContext Result.failure(Exception("تعذر تحميل المحافظات من Supabase (HTTP ${govResponse.code()})."))
            }
            val centerResponse = SupabaseClient.service.getShippingCenters()
            if (!centerResponse.isSuccessful) {
                return@withContext Result.failure(Exception("تعذر تحميل مراكز الشحن من Supabase (HTTP ${centerResponse.code()})."))
            }

            val governorates = govResponse.body().orEmpty().map { dto ->
                ShippingGovernorateEntity(
                    id = dto.governorate,
                    name = dto.governorate,
                    deliveryPrice = dto.price,
                    estimatedDays = "1-3 أيام",
                    isActive = dto.active ?: true
                )
            }
            val centers = centerResponse.body().orEmpty().map { dto ->
                ShippingCenterEntity(
                    id = dto.id,
                    governorateId = dto.governorate,
                    name = dto.center,
                    deliveryPrice = dto.price,
                    contactNumber = null,
                    isActive = dto.active ?: true
                )
            }
            // Do not clear either local list until both remote requests have succeeded.
            shippingDao.replaceShippingData(governorates, centers)
            android.util.Log.i("ElorySync", "Shipping synchronized: ${governorates.size} governorates, ${centers.size} centers")
            Result.success(Unit)
        } catch (e: Exception) {
            if (isNetworkException(e)) android.util.Log.w("ElorySync", "Shipping sync offline; cached data preserved.")
            else android.util.Log.e("ElorySync", "Shipping sync failed (${e.javaClass.simpleName}).", e)
            Result.failure(e)
        }
    }

}

class CustomerRepositoryImpl(
    private val database: PinkyDatabase
) : CustomerRepository {
    private val customerDao = database.customerDao()
    private val orderDao = database.orderDao()

    override fun getCustomersFlow(): Flow<List<Customer>> {
        return customerDao.getAllCustomersFlow().map { entities ->
            entities.map {
                Customer(
                    id = it.id,
                    name = it.name,
                    phone = it.phone,
                    email = it.email,
                    address = it.address,
                    governorate = it.governorate,
                    totalOrders = it.totalOrders,
                    totalSpend = it.totalSpend,
                    firstOrderDate = it.firstOrderDate,
                    lastOrderDate = it.lastOrderDate
                )
            }
        }.flowOn(Dispatchers.IO)
    }

    override suspend fun getCustomerById(customerId: String): Customer? = withContext(Dispatchers.IO) {
        val it = customerDao.getCustomerById(customerId) ?: return@withContext null
        Customer(it.id, it.name, it.phone, it.email, it.address, it.governorate, it.totalOrders, it.totalSpend, it.firstOrderDate, it.lastOrderDate)
    }

    override suspend fun getCustomerOrders(customerPhone: String): List<Order> = withContext(Dispatchers.IO) {
        orderDao.getOrdersByCustomerPhone(customerPhone).map { entity ->
            val items = orderDao.getOrderItems(entity.id).map { item ->
                OrderItem(item.id, item.productId, item.productName, item.variantName, item.color, item.size, item.quantity, item.unitPrice, item.lineTotal, item.imageUrl)
            }
            Order(
                id = entity.id,
                orderNumber = entity.orderNumber,
                customerName = entity.customerName,
                customerPhone = entity.customerPhone,
                customerAddress = entity.customerAddress,
                governorate = entity.governorate,
                shippingCenter = entity.shippingCenter,
                items = items,
                subtotalAmount = entity.subtotalAmount,
                shippingFee = entity.shippingFee,
                discountAmount = entity.discountAmount,
                totalAmount = entity.totalAmount,
                paymentMethod = PaymentMethod.fromString(entity.paymentMethod),
                paymentStatus = PaymentStatus.valueOf(entity.paymentStatus),
                status = OrderStatus.fromString(entity.status),
                createdAt = entity.createdAt,
                notes = entity.notes
            )
        }
    }

    override suspend fun syncCustomers(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val response = try {
                SupabaseClient.service.getCustomers()
            } catch (e: Exception) {
                null
            }
            if (response != null && response.isSuccessful) {
                val dtoList = response.body() ?: emptyList()
                val entities = dtoList.map { dto ->
                    CustomerEntity(
                        id = dto.id,
                        name = dto.name,
                        phone = dto.phone,
                        email = dto.email,
                        address = dto.address ?: "",
                        governorate = dto.governorate ?: "",
                        totalOrders = dto.totalOrders ?: 0,
                        totalSpend = dto.totalSpend ?: 0.0,
                        firstOrderDate = dto.firstOrderDate.toEpochMillisOrNull() ?: System.currentTimeMillis(),
                        lastOrderDate = dto.lastOrderDate.toEpochMillisOrNull() ?: System.currentTimeMillis()
                    )
                }
                customerDao.insertCustomers(entities)
                android.util.Log.d("SupabaseSync", "Table: customers | Operation: syncCustomers | Status: Success | Count: ${entities.size}")
                Result.success(Unit)
            } else {
                deriveCustomersFromLocalOrders()
            }
        } catch (e: Exception) {
            deriveCustomersFromLocalOrders()
        }
    }

    private suspend fun deriveCustomersFromLocalOrders(): Result<Unit> {
        return try {
            val ordersList = orderDao.getAllOrdersFlow().first()
            val derived = ordersList.groupBy { it.customerPhone }.map { (phone, ordersForCustomer) ->
                val firstOrder = ordersForCustomer.minByOrNull { it.createdAt }
                val lastOrder = ordersForCustomer.maxByOrNull { it.createdAt }
                val totalSpend = ordersForCustomer.sumOf { it.totalAmount }
                CustomerEntity(
                    id = "cust_${phone}",
                    name = firstOrder?.customerName ?: "عميل غير معروف",
                    phone = phone,
                    email = "",
                    address = firstOrder?.customerAddress ?: "",
                    governorate = firstOrder?.governorate ?: "",
                    totalOrders = ordersForCustomer.size,
                    totalSpend = totalSpend,
                    firstOrderDate = firstOrder?.createdAt ?: System.currentTimeMillis(),
                    lastOrderDate = lastOrder?.createdAt ?: System.currentTimeMillis()
                )
            }
            if (derived.isNotEmpty()) {
                customerDao.insertCustomers(derived)
            }
            android.util.Log.d("SupabaseSync", "Table: customers (derived) | Operation: syncCustomers | Status: Success | Count: ${derived.size}")
            Result.success(Unit)
        } catch (e: Exception) {
            android.util.Log.e("SupabaseError", "Table: customers (derived) | Operation: syncCustomers | Exception: ${e.message}", e)
            Result.failure(e)
        }
    }
}

class AuthRepositoryImpl(private val context: android.content.Context) : AuthRepository {
    private val prefs = context.getSharedPreferences("pinky_auth_prefs", android.content.Context.MODE_PRIVATE)
    private val dataStoreManager = com.pinky.dashboard.data.local.AuthDataStoreManager(context)
    private val _currentUser = MutableStateFlow<AdminUser?>(null)

    init {
        SupabaseClient.isSessionReady = false
    }

    override fun getCurrentUserFlow(): Flow<AdminUser?> = _currentUser.asStateFlow()

    private fun mapStaffProfile(profile: SupabaseStaffProfileDto, fallbackEmail: String): AdminUser? {
        val isActive = profile.active ?: profile.isActive ?: false
        if (!isActive) return null
        val profileEmail = profile.email?.trim()
        if (!profileEmail.isNullOrBlank() && !profileEmail.equals(fallbackEmail.trim(), ignoreCase = true)) return null
        val role = when (profile.role?.trim()?.lowercase()) {
            "owner" -> UserRole.OWNER
            "admin", "administrator" -> UserRole.ADMIN
            "employee", "staff" -> UserRole.EMPLOYEE
            else -> return null
        }
        val permissions = if (role == UserRole.OWNER) {
            Permission.entries.toSet()
        } else {
            profile.permissions.orEmpty()
                .filterValues { it }
                .keys
                .mapNotNull { Permission.fromStorageKey(it) }
                .toSet()
        }
        return AdminUser(
            id = profile.id,
            name = profile.name?.takeIf { it.isNotBlank() } ?: fallbackEmail.substringBefore("@"),
            email = profile.email?.takeIf { it.isNotBlank() } ?: fallbackEmail,
            role = role,
            permissions = permissions
        )
    }

    private suspend fun loadAuthorizedStaffProfile(userId: String, fallbackEmail: String): Result<AdminUser> {
        return try {
            val response = SupabaseClient.service.getStaffProfileById("eq.$userId", "*")
            if (!response.isSuccessful) {
                return Result.failure(Exception("تعذر التحقق من صلاحيات حساب الداشبورد (HTTP ${response.code()})."))
            }
            val profile = response.body()?.firstOrNull()
                ?: return Result.failure(Exception("الحساب غير مسجل كموظف نشط في Elory. اطلب إضافة حسابك إلى staff_profiles."))
            val user = mapStaffProfile(profile, fallbackEmail)
                ?: return Result.failure(Exception("هذا الحساب غير نشط أو أن دوره/صلاحياته غير معرّفة بشكل صحيح."))
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(Exception("تعذر التحقق من حساب الموظف على Supabase: ${e.localizedMessage ?: "خطأ اتصال"}"))
        }
    }

    private suspend fun clearLocalSession() {
        SupabaseClient.clearSession()
        dataStoreManager.clearSession()
        prefs.edit().clear().apply()
        _currentUser.value = null
    }

    override suspend fun initializeAuthSession(): Boolean = withContext(Dispatchers.IO) {
        android.util.Log.i("EloryAuth", "Session initialization started")
        try {
            // Read DataStore first. getSession also migrates legacy plaintext token values into Keystore encryption.
            var session = dataStoreManager.getSession()

            // One-time migration from older SharedPreferences sessions.
            if (session.accessToken.isNullOrBlank()) {
                val legacyToken = prefs.getString("user_token", null)
                val legacyRefreshToken = prefs.getString("refresh_token", null)
                val legacyExpiresAt = prefs.getLong("expires_at", 0L)
                val legacyId = prefs.getString("user_id", null)
                val legacyName = prefs.getString("user_name", null)
                val legacyEmail = prefs.getString("user_email", null)
                val legacyRole = prefs.getString("user_role", null)
                if (!legacyToken.isNullOrBlank() && !legacyId.isNullOrBlank() &&
                    !legacyName.isNullOrBlank() && !legacyEmail.isNullOrBlank() && !legacyRole.isNullOrBlank()) {
                    dataStoreManager.saveSession(
                        accessToken = legacyToken,
                        refreshToken = legacyRefreshToken,
                        expiresAt = legacyExpiresAt,
                        userId = legacyId,
                        userName = legacyName,
                        userEmail = legacyEmail,
                        userRole = legacyRole,
                        userPermissions = prefs.getString("user_permissions", "") ?: ""
                    )
                    prefs.edit().clear().apply()
                    session = dataStoreManager.getSession()
                }
            }

            val token = session.accessToken
            val id = session.userId
            val email = session.userEmail
            if (token.isNullOrBlank() || id.isNullOrBlank() || email.isNullOrBlank()) {
                SupabaseClient.isSessionReady = true
                SupabaseClient.isAuthenticated = false
                _currentUser.value = null
                return@withContext false
            }
            if (!SupabaseClient.hasValidConfiguration) {
                SupabaseClient.isSessionReady = true
                SupabaseClient.isAuthenticated = false
                return@withContext false
            }

            SupabaseClient.accessToken = token
            SupabaseClient.refreshToken = session.refreshToken
            SupabaseClient.expiresAt = session.expiresAt
            SupabaseClient.userId = id
            SupabaseClient.isAuthenticated = true
            SupabaseClient.isSessionReady = true

            if (session.expiresAt <= System.currentTimeMillis() + 60_000L) {
                if (!SupabaseClient.performTokenRefresh()) {
                    clearLocalSession()
                    SupabaseClient.isSessionReady = true
                    return@withContext false
                }
            }

            // Always reload the staff profile. Never grant a default ADMIN/OWNER role from local session data.
            val profileResult = loadAuthorizedStaffProfile(id, email)
            val user = profileResult.getOrElse {
                android.util.Log.w("EloryAuth", "Saved session rejected because its staff profile could not be verified.")
                clearLocalSession()
                SupabaseClient.isSessionReady = true
                return@withContext false
            }

            val currentToken = SupabaseClient.accessToken ?: token
            val currentRefresh = SupabaseClient.refreshToken
            val currentExpiry = SupabaseClient.expiresAt
            dataStoreManager.saveSession(
                accessToken = currentToken,
                refreshToken = currentRefresh,
                expiresAt = currentExpiry,
                userId = user.id,
                userName = user.name,
                userEmail = user.email,
                userRole = user.role.name,
                userPermissions = user.permissions.joinToString(",") { it.name }
            )
            _currentUser.value = user
            SupabaseClient.isAuthenticated = true
            android.util.Log.i("EloryAuth", "Authorized session restored for staff user ${user.id}")
            true
        } catch (e: Exception) {
            android.util.Log.e("EloryAuth", "Session initialization failed (${e.javaClass.simpleName}).")
            SupabaseClient.isSessionReady = true
            SupabaseClient.isAuthenticated = false
            false
        }
    }

    override suspend fun refreshAuthSessionIfNeeded(): Boolean = withContext(Dispatchers.IO) {
        val refreshed = SupabaseClient.performTokenRefresh()
        if (!refreshed) return@withContext false
        val current = _currentUser.value ?: return@withContext false
        val session = dataStoreManager.getSession()
        val response = SupabaseClient.service.getStaffProfileById("eq.${current.id}", "*")
        if (!response.isSuccessful) return@withContext false
        val profile = response.body()?.firstOrNull() ?: return@withContext false
        val updatedUser = mapStaffProfile(profile, current.email) ?: run {
            clearLocalSession()
            return@withContext false
        }
        _currentUser.value = updatedUser
        dataStoreManager.saveSession(
            accessToken = SupabaseClient.accessToken ?: session.accessToken.orEmpty(),
            refreshToken = SupabaseClient.refreshToken,
            expiresAt = SupabaseClient.expiresAt,
            userId = updatedUser.id,
            userName = updatedUser.name,
            userEmail = updatedUser.email,
            userRole = updatedUser.role.name,
            userPermissions = updatedUser.permissions.joinToString(",") { it.name }
        )
        true
    }

    override suspend fun login(email: String, pass: String): Result<AdminUser> = withContext(Dispatchers.IO) {
        if (!SupabaseClient.hasValidConfiguration) {
            return@withContext Result.failure(Exception("إعدادات اتصال Supabase غير مكتملة."))
        }
        if (email.isBlank() || pass.isBlank()) {
            return@withContext Result.failure(Exception("اكتب البريد الإلكتروني وكلمة المرور."))
        }

        try {
            val response = SupabaseClient.service.login(SupabaseLoginRequest(email.trim(), pass))
            if (!response.isSuccessful) {
                val errorCode = response.code()
                val message = if (errorCode == 400 || errorCode == 401) {
                    "البريد الإلكتروني أو كلمة المرور غير صحيحة."
                } else {
                    "تعذر تسجيل الدخول إلى Supabase (HTTP $errorCode)."
                }
                return@withContext Result.failure(Exception(message))
            }

            val loginData = response.body()
                ?: return@withContext Result.failure(Exception("استجابة تسجيل الدخول من Supabase فارغة."))
            val computedExpiresAt = System.currentTimeMillis() + loginData.expiresIn * 1000L
            SupabaseClient.accessToken = loginData.accessToken
            SupabaseClient.refreshToken = loginData.refreshToken
            SupabaseClient.userId = loginData.user.id
            SupabaseClient.expiresAt = computedExpiresAt
            SupabaseClient.isAuthenticated = true
            SupabaseClient.isSessionReady = true

            // An authenticated Supabase user must also have an active staff_profiles row.
            val profileResult = loadAuthorizedStaffProfile(loginData.user.id, email.trim())
            val user = profileResult.getOrElse {
                clearLocalSession()
                SupabaseClient.isSessionReady = true
                return@withContext Result.failure(it)
            }

            dataStoreManager.saveSession(
                accessToken = loginData.accessToken,
                refreshToken = loginData.refreshToken,
                expiresAt = computedExpiresAt,
                userId = user.id,
                userName = user.name,
                userEmail = user.email,
                userRole = user.role.name,
                userPermissions = user.permissions.joinToString(",") { it.name }
            )
            prefs.edit().clear().apply()
            _currentUser.value = user
            Result.success(user)
        } catch (e: Exception) {
            SupabaseClient.isAuthenticated = false
            SupabaseClient.isSessionReady = true
            Result.failure(Exception("حدث خطأ أثناء الاتصال بخدمة تسجيل الدخول: ${e.localizedMessage ?: "خطأ غير معروف"}"))
        }
    }

    override suspend fun logout() {
        clearLocalSession()
        android.util.Log.i("EloryAuth", "User logged out")
    }

    override suspend fun switchRoleForTesting(role: UserRole) {
        // This is a development-only preview. Never permit client-side role changes in release builds.
        if (!BuildConfig.DEBUG) return
        val current = _currentUser.value ?: return
        if (current.role != UserRole.OWNER) return
        _currentUser.value = current.copy(role = role, permissions = Permission.defaultPermissionsFor(role))
    }
}

class AnalyticsRepositoryImpl(
    private val orderRepository: OrderRepository,
    private val productRepository: ProductRepository,
    private val authRepository: AuthRepository
) : AnalyticsRepository {

    override fun getAnalyticsFlow(timeframeDays: Int): Flow<AnalyticsData> {
        return combine(
            orderRepository.getOrdersFlow(),
            productRepository.getProductsFlow(),
            authRepository.getCurrentUserFlow()
        ) { orders, products, currentUser ->
            val cutoff = System.currentTimeMillis() - (timeframeDays.toLong() * 24 * 60 * 60 * 1000)
            val filteredOrders = orders.filter { it.createdAt >= cutoff && it.status != OrderStatus.CANCELLED }

            val totalSales = filteredOrders.sumOf { it.totalAmount }
            val totalOrders = filteredOrders.size
            val totalProductsSold = filteredOrders.sumOf { o -> o.items.sumOf { it.quantity } }

            // Calculate profit only if current user has permission!
            val canViewProfit = currentUser?.canViewProfit == true
            val totalProfit = if (canViewProfit) {
                // Real profit: (Price - WholesalePrice) * qty
                val wholesaleMap = products.associate { it.id to (it.wholesalePrice ?: (it.price * 0.7)) }
                filteredOrders.sumOf { o ->
                    o.items.sumOf { item ->
                        val cost = wholesaleMap[item.productId] ?: (item.unitPrice * 0.7)
                        (item.unitPrice - cost) * item.quantity
                    }
                }
            } else {
                null
            }

            // Group daily metrics
            val dateFormat = SimpleDateFormat("MM/dd", Locale.getDefault())
            val dailyGrouped = filteredOrders.groupBy {
                dateFormat.format(Date(it.createdAt))
            }
            val dailyMetrics = dailyGrouped.map { (day, dayOrders) ->
                DailyMetric(
                    dayLabel = day,
                    salesAmount = dayOrders.sumOf { it.totalAmount },
                    ordersCount = dayOrders.size
                )
            }.takeLast(7)

            // Top products
            val productSalesMap = mutableMapOf<String, Pair<Int, Double>>()
            for (order in filteredOrders) {
                for (item in order.items) {
                    val current = productSalesMap[item.productId] ?: (0 to 0.0)
                    productSalesMap[item.productId] = (current.first + item.quantity) to (current.second + item.lineTotal)
                }
            }
            val topProducts = productSalesMap.entries.sortedByDescending { it.value.second }.take(5).map { entry ->
                val p = products.firstOrNull { it.id == entry.key }
                TopProductMetric(
                    productId = entry.key,
                    productName = p?.name ?: "منتج متجر Elory",
                    unitsSold = entry.value.first,
                    totalRevenue = entry.value.second,
                    imageUrl = p?.imageUrl
                )
            }

            // Orders by status
            val statusMap = orders.groupBy { it.status }.mapValues { it.value.size }

            // Sales by governorate
            val govMap = filteredOrders.groupBy { it.governorate }.mapValues { it.value.sumOf { o -> o.totalAmount } }

            AnalyticsData(
                totalSales = totalSales,
                totalOrders = totalOrders,
                totalProductsSold = totalProductsSold,
                totalProfit = totalProfit,
                dailyMetrics = dailyMetrics,
                topSellingProducts = topProducts,
                ordersByStatus = statusMap,
                salesByGovernorate = govMap
            )
        }
    }
}
