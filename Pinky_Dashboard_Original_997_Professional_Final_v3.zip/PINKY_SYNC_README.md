# Pinky Dashboard — Store Sync v3

This version keeps the existing Pinky Dashboard UI/features and fixes the live Store/Supabase connection.

## Included fixes

- Real categories from `public.categories`, seeded with the seven categories currently shown by the store.
- Category add/edit/delete uses real UUIDs and persists to Supabase.
- Renaming a category also updates existing products that store the category by name.
- Products sync from `products`; if the admin table is temporarily restricted/empty, the dashboard falls back to the same `catalog_products` view used by the customer store.
- Local seed/mock product/order rows are cleared after a successful server sync so old dashboard demo data does not remain mixed with the live store.
- Existing customer-store order JSON (`name`, `price`, `image`) is now understood by the dashboard in addition to normalized `order_items` (`product_name`, `unit_price`, `image_url`).
- Order product name, price and image are restored from the order snapshot or product table.
- Product/category saves are server-first and verified by a read-after-write before the local cache is updated.
- Shipping saves are verified after writing to Supabase.
- Owner/staff RLS helper and owner profile repair are included in `pinky_store_dashboard_sync.sql`.
- Customer website categories now read from `categories` instead of being permanently hardcoded.
- Customer website no longer replaces a successful empty catalog with fake demo products.
- Structured `site_customizations` values saved by the dashboard are applied by the website.
- GitHub Actions build workflow remains included and handles empty optional Gemini/owner-password secrets safely.

## Supabase step

Run `pinky_store_dashboard_sync.sql` once in the Supabase SQL Editor, then sign in to Pinky Dashboard and press refresh.

## GitHub Actions secrets

Recommended repository secrets:

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `OWNER_PASSWORD` (optional)
- `GEMINI_API_KEY` (optional)

The workflow can still compile when the optional two secrets are empty.
