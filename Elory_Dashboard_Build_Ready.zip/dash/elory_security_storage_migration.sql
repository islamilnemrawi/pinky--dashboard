-- ============================================================================
-- ELORY DASHBOARD — SECURITY + STORAGE COMPATIBILITY MIGRATION
-- Apply once from Supabase SQL Editor before using the Android dashboard.
-- This migration intentionally preserves public storefront checkout inserts.
-- It does NOT create or change product/order data, table columns, or bucket IDs.
-- ============================================================================

DO $$
BEGIN
  IF to_regclass('public.staff_profiles') IS NULL THEN
    RAISE EXCEPTION 'Elory migration requires public.staff_profiles. Create/verify the staff_profiles table before applying this migration.';
  END IF;
END;
$$;

-- Resolve active staff only from the authenticated user's own profile row.
-- No hard-coded owner UUID or email bypass exists in this migration.
CREATE OR REPLACE FUNCTION public.is_elora_staff()
RETURNS boolean
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog
AS $$
DECLARE
  v_profile pg_catalog.jsonb;
  v_active boolean;
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN false;
  END IF;

  SELECT pg_catalog.to_jsonb(sp)
    INTO v_profile
    FROM public.staff_profiles AS sp
   WHERE sp.id = auth.uid()
   LIMIT 1;

  IF v_profile IS NULL THEN
    RETURN false;
  END IF;

  v_active := COALESCE(
    NULLIF(v_profile ->> 'active', '')::boolean,
    NULLIF(v_profile ->> 'is_active', '')::boolean,
    false
  );

  RETURN v_active;
EXCEPTION WHEN OTHERS THEN
  RETURN false;
END;
$$;

-- Understands the dashboard's enum permission keys and the earlier dotted
-- JSON keys. Values must be true; no substring/partial text matching is used.
CREATE OR REPLACE FUNCTION public.has_staff_permission(required_permission text)
RETURNS boolean
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog
AS $$
DECLARE
  v_profile pg_catalog.jsonb;
  v_permissions pg_catalog.jsonb;
  v_permission_text pg_catalog.text;
  v_permission_key pg_catalog.text;
  v_alias pg_catalog.text;
  v_role pg_catalog.text;
  v_token pg_catalog.text;
  v_value pg_catalog.text;
  v_active boolean;
BEGIN
  IF auth.uid() IS NULL OR required_permission IS NULL OR pg_catalog.btrim(required_permission) = '' THEN
    RETURN false;
  END IF;

  SELECT pg_catalog.to_jsonb(sp)
    INTO v_profile
    FROM public.staff_profiles AS sp
   WHERE sp.id = auth.uid()
   LIMIT 1;

  IF v_profile IS NULL THEN
    RETURN false;
  END IF;

  v_active := COALESCE(
    NULLIF(v_profile ->> 'active', '')::boolean,
    NULLIF(v_profile ->> 'is_active', '')::boolean,
    false
  );
  IF v_active IS NOT TRUE THEN
    RETURN false;
  END IF;

  v_role := pg_catalog.lower(pg_catalog.btrim(COALESCE(v_profile ->> 'role', '')));
  IF v_role = 'owner' THEN
    RETURN true;
  END IF;

  v_permission_key := pg_catalog.upper(pg_catalog.btrim(required_permission));
  v_permissions := v_profile -> 'permissions';

  -- Accept JSONB objects, JSON stored in a text column, and legacy CSV text.
  IF pg_catalog.jsonb_typeof(v_permissions) = 'string' THEN
    v_permission_text := v_permissions #>> '{}';
    BEGIN
      v_permissions := v_permission_text::jsonb;
    EXCEPTION WHEN OTHERS THEN
      v_permissions := '{}'::jsonb;
      FOREACH v_token IN ARRAY pg_catalog.string_to_array(v_permission_text, ',') LOOP
        v_token := pg_catalog.upper(pg_catalog.btrim(v_token));
        IF v_token <> '' THEN
          v_permissions := v_permissions || pg_catalog.jsonb_build_object(v_token, true, pg_catalog.lower(v_token), true);
        END IF;
      END LOOP;
    END;
  ELSIF pg_catalog.jsonb_typeof(v_permissions) = 'array' THEN
    v_permission_text := v_permissions::text;
    v_permissions := '{}'::jsonb;
    FOR v_token IN SELECT pg_catalog.jsonb_array_elements_text(v_permission_text::jsonb) LOOP
      v_token := pg_catalog.upper(pg_catalog.btrim(v_token));
      IF v_token <> '' THEN
        v_permissions := v_permissions || pg_catalog.jsonb_build_object(v_token, true, pg_catalog.lower(v_token), true);
      END IF;
    END LOOP;
  ELSIF pg_catalog.jsonb_typeof(v_permissions) <> 'object' THEN
    v_permissions := '{}'::jsonb;
  END IF;

  v_value := pg_catalog.lower(COALESCE(v_permissions ->> v_permission_key, 'false'));
  IF v_value IN ('true', '1', 'yes') THEN
    RETURN true;
  END IF;

  -- Explicit legacy dotted-key mapping; never use fuzzy/substring grants.
  v_alias := CASE v_permission_key
    WHEN 'VIEW_DASHBOARD' THEN 'dashboard.view'
    WHEN 'MANAGE_ORDERS' THEN 'orders.manage'
    WHEN 'UPDATE_ORDER_STATUS' THEN 'orders.update_status'
    WHEN 'MANAGE_PRODUCTS' THEN 'products.manage'
    WHEN 'VIEW_WHOLESALE_PRICES' THEN 'products.wholesale_prices'
    WHEN 'VIEW_INTERNAL_CODES' THEN 'products.internal_codes'
    WHEN 'MANAGE_CATEGORIES' THEN 'categories.manage'
    WHEN 'MANAGE_OFFERS' THEN 'offers.manage'
    WHEN 'MANAGE_COUPONS' THEN 'coupons.manage'
    WHEN 'MANAGE_CUSTOMERS' THEN 'customers.manage'
    WHEN 'MANAGE_PRIME' THEN 'prime.manage'
    WHEN 'MANAGE_SHIPPING' THEN 'shipping.manage'
    WHEN 'MANAGE_PAYMENT_METHODS' THEN 'payments.manage'
    WHEN 'MANAGE_STAFF' THEN 'staff.manage'
    WHEN 'MANAGE_WEBSITE_EDITOR' THEN 'website.manage'
    WHEN 'VIEW_ANALYTICS' THEN 'analytics.view'
    WHEN 'VIEW_PROFIT' THEN 'analytics.profit'
    WHEN 'VIEW_NOTIFICATIONS' THEN 'notifications.view'
    WHEN 'MANAGE_SETTINGS' THEN 'settings.manage'
    WHEN 'VIEW_ORDERS' THEN 'orders.view'
    WHEN 'VIEW_PRODUCTS' THEN 'products.view'
    WHEN 'VIEW_OFFERS' THEN 'offers.view'
    WHEN 'VIEW_CATEGORIES' THEN 'categories.view'
    WHEN 'VIEW_COUPONS' THEN 'coupons.view'
    WHEN 'VIEW_SHIPPING' THEN 'shipping.view'
    WHEN 'VIEW_SETTINGS' THEN 'settings.view'
    ELSE NULL
  END;

  IF v_alias IS NOT NULL THEN
    v_value := pg_catalog.lower(COALESCE(v_permissions ->> v_alias, 'false'));
    IF v_value IN ('true', '1', 'yes') THEN
      RETURN true;
    END IF;
  END IF;

  -- A manage permission implies its corresponding view permission only.
  IF v_permission_key = 'VIEW_ORDERS'
     AND pg_catalog.lower(COALESCE(v_permissions ->> 'orders.manage', 'false')) IN ('true', '1', 'yes') THEN
    RETURN true;
  END IF;
  IF v_permission_key = 'VIEW_PRODUCTS'
     AND pg_catalog.lower(COALESCE(v_permissions ->> 'products.manage', 'false')) IN ('true', '1', 'yes') THEN
    RETURN true;
  END IF;
  IF v_permission_key = 'VIEW_OFFERS'
     AND pg_catalog.lower(COALESCE(v_permissions ->> 'offers.manage', 'false')) IN ('true', '1', 'yes') THEN
    RETURN true;
  END IF;
  IF v_permission_key = 'VIEW_CATEGORIES'
     AND pg_catalog.lower(COALESCE(v_permissions ->> 'categories.manage', 'false')) IN ('true', '1', 'yes') THEN
    RETURN true;
  END IF;
  IF v_permission_key = 'VIEW_COUPONS'
     AND pg_catalog.lower(COALESCE(v_permissions ->> 'coupons.manage', 'false')) IN ('true', '1', 'yes') THEN
    RETURN true;
  END IF;
  IF v_permission_key = 'VIEW_SHIPPING'
     AND pg_catalog.lower(COALESCE(v_permissions ->> 'shipping.manage', 'false')) IN ('true', '1', 'yes') THEN
    RETURN true;
  END IF;
  IF v_permission_key = 'VIEW_SETTINGS'
     AND pg_catalog.lower(COALESCE(v_permissions ->> 'settings.manage', 'false')) IN ('true', '1', 'yes') THEN
    RETURN true;
  END IF;

  RETURN false;
EXCEPTION WHEN OTHERS THEN
  RETURN false;
END;
$$;

-- Only an already-authorized owner may create or promote another owner profile.
CREATE OR REPLACE FUNCTION public.is_elory_owner()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog
AS $$
  SELECT EXISTS (
    SELECT 1
      FROM public.staff_profiles AS sp
     WHERE sp.id = auth.uid()
       AND pg_catalog.lower(pg_catalog.btrim(COALESCE(sp.role::text, ''))) = 'owner'
       AND COALESCE(
         NULLIF(pg_catalog.to_jsonb(sp) ->> 'active', '')::boolean,
         NULLIF(pg_catalog.to_jsonb(sp) ->> 'is_active', '')::boolean,
         false
       ) IS TRUE
  );
$$;

REVOKE ALL ON FUNCTION public.is_elora_staff() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.has_staff_permission(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.is_elory_owner() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.is_elora_staff() TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_staff_permission(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_elory_owner() TO authenticated;

-- Re-bind the policies used by the storefront/dashboard. Public product reads
-- continue to use the existing catalog_products view, not the private products table.
DO $$
BEGIN
  -- Staff profiles: self-read or MANAGE_STAFF; modifications require MANAGE_STAFF.
  EXECUTE 'ALTER TABLE public.staff_profiles ENABLE ROW LEVEL SECURITY';
  EXECUTE 'DROP POLICY IF EXISTS select_staff_profiles ON public.staff_profiles';
  EXECUTE 'DROP POLICY IF EXISTS manage_staff_profiles ON public.staff_profiles';
  EXECUTE 'CREATE POLICY select_staff_profiles ON public.staff_profiles FOR SELECT TO authenticated USING (auth.uid() = id OR public.has_staff_permission(''MANAGE_STAFF''))';
  EXECUTE 'CREATE POLICY manage_staff_profiles ON public.staff_profiles FOR ALL TO authenticated USING (public.has_staff_permission(''MANAGE_STAFF'') AND (pg_catalog.lower(pg_catalog.btrim(COALESCE(role::text, ''''))) <> ''owner'' OR public.is_elory_owner())) WITH CHECK (public.has_staff_permission(''MANAGE_STAFF'') AND (pg_catalog.lower(pg_catalog.btrim(COALESCE(role::text, ''''))) <> ''owner'' OR public.is_elory_owner()))';

  IF to_regclass('public.customers') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY';
    EXECUTE 'DROP POLICY IF EXISTS select_customers ON public.customers';
    EXECUTE 'DROP POLICY IF EXISTS manage_customers ON public.customers';
    EXECUTE 'DROP POLICY IF EXISTS insert_public_customers ON public.customers';
    EXECUTE 'CREATE POLICY select_customers ON public.customers FOR SELECT TO authenticated USING (public.has_staff_permission(''MANAGE_CUSTOMERS''))';
    EXECUTE 'CREATE POLICY manage_customers ON public.customers FOR ALL TO authenticated USING (public.has_staff_permission(''MANAGE_CUSTOMERS'')) WITH CHECK (public.has_staff_permission(''MANAGE_CUSTOMERS''))';
    -- Keep storefront customer creation available, but do not expose customer reads to anon.
    EXECUTE $policy$
      CREATE POLICY insert_public_customers ON public.customers
      FOR INSERT TO anon
      WITH CHECK (
        pg_catalog.length(pg_catalog.btrim(COALESCE(name, ''))) BETWEEN 2 AND 120
        AND pg_catalog.length(pg_catalog.regexp_replace(COALESCE(phone, ''), '[^0-9]', '', 'g')) BETWEEN 10 AND 15
      )
    $policy$;
  END IF;

  IF to_regclass('public.orders') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY';
    EXECUTE 'DROP POLICY IF EXISTS select_orders ON public.orders';
    EXECUTE 'DROP POLICY IF EXISTS insert_orders ON public.orders';
    EXECUTE 'DROP POLICY IF EXISTS update_orders ON public.orders';
    EXECUTE 'DROP POLICY IF EXISTS delete_orders ON public.orders';
    EXECUTE 'CREATE POLICY select_orders ON public.orders FOR SELECT TO authenticated USING (public.has_staff_permission(''MANAGE_ORDERS'') OR public.has_staff_permission(''UPDATE_ORDER_STATUS''))';
    -- Keep anonymous checkout insertion intact for the existing Elory website.
    EXECUTE 'CREATE POLICY insert_orders ON public.orders FOR INSERT TO anon, authenticated WITH CHECK (true)';
    EXECUTE 'CREATE POLICY update_orders ON public.orders FOR UPDATE TO authenticated USING (public.has_staff_permission(''MANAGE_ORDERS'') OR public.has_staff_permission(''UPDATE_ORDER_STATUS'')) WITH CHECK (public.has_staff_permission(''MANAGE_ORDERS'') OR public.has_staff_permission(''UPDATE_ORDER_STATUS''))';
    EXECUTE 'CREATE POLICY delete_orders ON public.orders FOR DELETE TO authenticated USING (public.has_staff_permission(''MANAGE_ORDERS''))';
  END IF;

  IF to_regclass('public.order_items') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY';
    EXECUTE 'DROP POLICY IF EXISTS select_order_items ON public.order_items';
    EXECUTE 'DROP POLICY IF EXISTS insert_order_items ON public.order_items';
    EXECUTE 'DROP POLICY IF EXISTS update_order_items ON public.order_items';
    EXECUTE 'DROP POLICY IF EXISTS delete_order_items ON public.order_items';
    EXECUTE 'CREATE POLICY select_order_items ON public.order_items FOR SELECT TO authenticated USING (public.has_staff_permission(''MANAGE_ORDERS'') OR public.has_staff_permission(''UPDATE_ORDER_STATUS''))';
    -- Keep anonymous checkout item insertion intact for the existing Elory website.
    EXECUTE 'CREATE POLICY insert_order_items ON public.order_items FOR INSERT TO anon, authenticated WITH CHECK (true)';
    EXECUTE 'CREATE POLICY update_order_items ON public.order_items FOR UPDATE TO authenticated USING (public.has_staff_permission(''MANAGE_ORDERS'')) WITH CHECK (public.has_staff_permission(''MANAGE_ORDERS''))';
    EXECUTE 'CREATE POLICY delete_order_items ON public.order_items FOR DELETE TO authenticated USING (public.has_staff_permission(''MANAGE_ORDERS''))';
  END IF;

  IF to_regclass('public.products') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE public.products ENABLE ROW LEVEL SECURITY';
    EXECUTE 'DROP POLICY IF EXISTS select_products ON public.products';
    EXECUTE 'DROP POLICY IF EXISTS modify_products ON public.products';
    EXECUTE 'CREATE POLICY select_products ON public.products FOR SELECT TO authenticated USING (public.has_staff_permission(''MANAGE_PRODUCTS''))';
    EXECUTE 'CREATE POLICY modify_products ON public.products FOR ALL TO authenticated USING (public.has_staff_permission(''MANAGE_PRODUCTS'')) WITH CHECK (public.has_staff_permission(''MANAGE_PRODUCTS''))';
  END IF;

  IF to_regclass('public.categories') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY';
    EXECUTE 'DROP POLICY IF EXISTS select_categories ON public.categories';
    EXECUTE 'DROP POLICY IF EXISTS modify_categories ON public.categories';
    EXECUTE 'CREATE POLICY select_categories ON public.categories FOR SELECT USING (true)';
    EXECUTE 'CREATE POLICY modify_categories ON public.categories FOR ALL TO authenticated USING (public.has_staff_permission(''MANAGE_CATEGORIES'')) WITH CHECK (public.has_staff_permission(''MANAGE_CATEGORIES''))';
  END IF;

  IF to_regclass('public.offers') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE public.offers ENABLE ROW LEVEL SECURITY';
    EXECUTE 'DROP POLICY IF EXISTS select_offers ON public.offers';
    EXECUTE 'DROP POLICY IF EXISTS modify_offers ON public.offers';
    EXECUTE 'CREATE POLICY select_offers ON public.offers FOR SELECT USING (true)';
    EXECUTE 'CREATE POLICY modify_offers ON public.offers FOR ALL TO authenticated USING (public.has_staff_permission(''MANAGE_OFFERS'')) WITH CHECK (public.has_staff_permission(''MANAGE_OFFERS''))';
  END IF;

  IF to_regclass('public.banners') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE public.banners ENABLE ROW LEVEL SECURITY';
    EXECUTE 'DROP POLICY IF EXISTS select_banners ON public.banners';
    EXECUTE 'DROP POLICY IF EXISTS modify_banners ON public.banners';
    EXECUTE 'CREATE POLICY select_banners ON public.banners FOR SELECT USING (true)';
    EXECUTE 'CREATE POLICY modify_banners ON public.banners FOR ALL TO authenticated USING (public.has_staff_permission(''MANAGE_OFFERS'') OR public.has_staff_permission(''MANAGE_WEBSITE_EDITOR'')) WITH CHECK (public.has_staff_permission(''MANAGE_OFFERS'') OR public.has_staff_permission(''MANAGE_WEBSITE_EDITOR''))';
  END IF;

  IF to_regclass('public.coupons') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY';
    EXECUTE 'DROP POLICY IF EXISTS select_coupons ON public.coupons';
    EXECUTE 'DROP POLICY IF EXISTS modify_coupons ON public.coupons';
    EXECUTE 'CREATE POLICY select_coupons ON public.coupons FOR SELECT USING (true)';
    EXECUTE 'CREATE POLICY modify_coupons ON public.coupons FOR ALL TO authenticated USING (public.has_staff_permission(''MANAGE_COUPONS'')) WITH CHECK (public.has_staff_permission(''MANAGE_COUPONS''))';
  END IF;

  IF to_regclass('public.shipping_governorates') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE public.shipping_governorates ENABLE ROW LEVEL SECURITY';
    EXECUTE 'DROP POLICY IF EXISTS select_govs ON public.shipping_governorates';
    EXECUTE 'DROP POLICY IF EXISTS modify_govs ON public.shipping_governorates';
    EXECUTE 'CREATE POLICY select_govs ON public.shipping_governorates FOR SELECT USING (true)';
    EXECUTE 'CREATE POLICY modify_govs ON public.shipping_governorates FOR ALL TO authenticated USING (public.has_staff_permission(''MANAGE_SHIPPING'')) WITH CHECK (public.has_staff_permission(''MANAGE_SHIPPING''))';
  END IF;

  IF to_regclass('public.shipping_centers') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE public.shipping_centers ENABLE ROW LEVEL SECURITY';
    EXECUTE 'DROP POLICY IF EXISTS select_centers ON public.shipping_centers';
    EXECUTE 'DROP POLICY IF EXISTS modify_centers ON public.shipping_centers';
    EXECUTE 'CREATE POLICY select_centers ON public.shipping_centers FOR SELECT USING (true)';
    EXECUTE 'CREATE POLICY modify_centers ON public.shipping_centers FOR ALL TO authenticated USING (public.has_staff_permission(''MANAGE_SHIPPING'')) WITH CHECK (public.has_staff_permission(''MANAGE_SHIPPING''))';
  END IF;

  IF to_regclass('public.prime_subscriptions') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE public.prime_subscriptions ENABLE ROW LEVEL SECURITY';
    EXECUTE 'DROP POLICY IF EXISTS select_prime ON public.prime_subscriptions';
    EXECUTE 'DROP POLICY IF EXISTS modify_prime ON public.prime_subscriptions';
    EXECUTE 'CREATE POLICY select_prime ON public.prime_subscriptions FOR SELECT TO authenticated USING (public.has_staff_permission(''MANAGE_PRIME'') OR public.has_staff_permission(''MANAGE_SETTINGS''))';
    EXECUTE 'CREATE POLICY modify_prime ON public.prime_subscriptions FOR ALL TO authenticated USING (public.has_staff_permission(''MANAGE_PRIME'')) WITH CHECK (public.has_staff_permission(''MANAGE_PRIME''))';
  END IF;

  IF to_regclass('public.site_customizations') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE public.site_customizations ENABLE ROW LEVEL SECURITY';
    EXECUTE 'DROP POLICY IF EXISTS select_site_cust ON public.site_customizations';
    EXECUTE 'DROP POLICY IF EXISTS modify_site_cust ON public.site_customizations';
    EXECUTE 'CREATE POLICY select_site_cust ON public.site_customizations FOR SELECT USING (true)';
    EXECUTE 'CREATE POLICY modify_site_cust ON public.site_customizations FOR ALL TO authenticated USING (public.has_staff_permission(''MANAGE_WEBSITE_EDITOR'')) WITH CHECK (public.has_staff_permission(''MANAGE_WEBSITE_EDITOR''))';
  END IF;

  IF to_regclass('public.store_settings') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE public.store_settings ENABLE ROW LEVEL SECURITY';
    EXECUTE 'DROP POLICY IF EXISTS select_store_settings ON public.store_settings';
    EXECUTE 'DROP POLICY IF EXISTS modify_store_settings ON public.store_settings';
    EXECUTE 'CREATE POLICY select_store_settings ON public.store_settings FOR SELECT USING (true)';
    EXECUTE 'CREATE POLICY modify_store_settings ON public.store_settings FOR ALL TO authenticated USING (public.has_staff_permission(''MANAGE_SETTINGS'') OR public.has_staff_permission(''MANAGE_WEBSITE_EDITOR'')) WITH CHECK (public.has_staff_permission(''MANAGE_SETTINGS'') OR public.has_staff_permission(''MANAGE_WEBSITE_EDITOR''))';
  END IF;

  IF to_regclass('public.dashboard_push_devices') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE public.dashboard_push_devices ENABLE ROW LEVEL SECURITY';
    EXECUTE 'DROP POLICY IF EXISTS select_push ON public.dashboard_push_devices';
    EXECUTE 'DROP POLICY IF EXISTS insert_push ON public.dashboard_push_devices';
    EXECUTE 'DROP POLICY IF EXISTS update_push ON public.dashboard_push_devices';
    EXECUTE 'DROP POLICY IF EXISTS delete_push ON public.dashboard_push_devices';
    EXECUTE 'CREATE POLICY select_push ON public.dashboard_push_devices FOR SELECT TO authenticated USING (public.is_elora_staff())';
    EXECUTE 'CREATE POLICY insert_push ON public.dashboard_push_devices FOR INSERT TO authenticated WITH CHECK (public.is_elora_staff())';
    EXECUTE 'CREATE POLICY update_push ON public.dashboard_push_devices FOR UPDATE TO authenticated USING (public.is_elora_staff()) WITH CHECK (public.is_elora_staff())';
    EXECUTE 'CREATE POLICY delete_push ON public.dashboard_push_devices FOR DELETE TO authenticated USING (public.is_elora_staff())';
  END IF;
END;
$$;

-- Preserve the current public bucket IDs used in WebsiteEditorScreen and by
-- existing Elory storefront media URLs. Do not rename the buckets.
INSERT INTO storage.buckets (id, name, public)
VALUES ('pinky-products', 'pinky-products', true), ('pinky-banners', 'pinky-banners', true)
ON CONFLICT (id) DO UPDATE SET public = true;

DROP POLICY IF EXISTS elory_public_media_read ON storage.objects;
DROP POLICY IF EXISTS elory_products_media_insert ON storage.objects;
DROP POLICY IF EXISTS elory_products_media_update ON storage.objects;
DROP POLICY IF EXISTS elory_products_media_delete ON storage.objects;
DROP POLICY IF EXISTS elory_banners_media_insert ON storage.objects;
DROP POLICY IF EXISTS elory_banners_media_update ON storage.objects;
DROP POLICY IF EXISTS elory_banners_media_delete ON storage.objects;

CREATE POLICY elory_public_media_read ON storage.objects
  FOR SELECT USING (bucket_id IN ('pinky-products', 'pinky-banners'));

CREATE POLICY elory_products_media_insert ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'pinky-products' AND (public.has_staff_permission('MANAGE_PRODUCTS') OR public.has_staff_permission('MANAGE_CATEGORIES') OR public.has_staff_permission('MANAGE_WEBSITE_EDITOR')));
CREATE POLICY elory_products_media_update ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'pinky-products' AND (public.has_staff_permission('MANAGE_PRODUCTS') OR public.has_staff_permission('MANAGE_CATEGORIES') OR public.has_staff_permission('MANAGE_WEBSITE_EDITOR')))
  WITH CHECK (bucket_id = 'pinky-products' AND (public.has_staff_permission('MANAGE_PRODUCTS') OR public.has_staff_permission('MANAGE_CATEGORIES') OR public.has_staff_permission('MANAGE_WEBSITE_EDITOR')));
CREATE POLICY elory_products_media_delete ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'pinky-products' AND (public.has_staff_permission('MANAGE_PRODUCTS') OR public.has_staff_permission('MANAGE_CATEGORIES') OR public.has_staff_permission('MANAGE_WEBSITE_EDITOR')));

CREATE POLICY elory_banners_media_insert ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'pinky-banners' AND (public.has_staff_permission('MANAGE_OFFERS') OR public.has_staff_permission('MANAGE_WEBSITE_EDITOR')));
CREATE POLICY elory_banners_media_update ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'pinky-banners' AND (public.has_staff_permission('MANAGE_OFFERS') OR public.has_staff_permission('MANAGE_WEBSITE_EDITOR')))
  WITH CHECK (bucket_id = 'pinky-banners' AND (public.has_staff_permission('MANAGE_OFFERS') OR public.has_staff_permission('MANAGE_WEBSITE_EDITOR')));
CREATE POLICY elory_banners_media_delete ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'pinky-banners' AND (public.has_staff_permission('MANAGE_OFFERS') OR public.has_staff_permission('MANAGE_WEBSITE_EDITOR')));

-- Intentionally not changing orders/order_items anonymous INSERT policies:
-- existing Elory website checkout depends on them. Review rate-limiting and
-- server-side order validation separately before opening to large public traffic.

COMMENT ON FUNCTION public.has_staff_permission(text) IS
'Elory dashboard role/permission check. Exact JSONB/legacy key matching only; no hard-coded owner identities.';

-- ============================================================================
-- END. Run from Supabase SQL Editor, then sign in with an active staff_profiles
-- row whose id equals the Supabase Auth user UUID. Role owner gets all features.
-- ============================================================================
